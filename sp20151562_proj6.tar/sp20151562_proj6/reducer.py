#!/usr/bin/env python

# import modules
from itertools import groupby
from operator import itemgetter
import sys

# 'file' in this case is STDIN
def read_mapper_output(file, separator='\t'):
    # Go through each line
	for line in file:
        # Right strip out the separator character
		yield line.rstrip().split(separator)

def main(separator='\t'):
    # Read the data using read_mapper_output
	data = read_mapper_output(sys.stdin, separator=separator)
    #   generator를 data로 받아 이를 for 문을 통해 읽는다.
	for current_word, group in groupby(data, itemgetter(0)):
		try:
            # groupby를 통해 받은 list들을 for 문을 통해 읽으며
			# 가장 큰 값을 저장한다.
			total_count = max(float(count) for current_word, count in group)
            # Write to stdout
			print("%s%s%f"%(current_word, separator, total_count))
		except ValueError:
            # Count was not a number, so do nothing
			pass

if __name__ == "__main__":
	main()
