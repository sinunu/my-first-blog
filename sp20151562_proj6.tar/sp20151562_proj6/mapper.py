#!/usr/bin/env python

# Use the sys module
import sys

# 'file' in this case is STDIN
def read_input(file):
    # ','를 기준으로 나누어 반환한다.
	for line in file:
		yield line.split(',')

def main(separator='\t'):
    # Read the data using read_input
	data = read_input(sys.stdin)
    # Process each word returned from read_input
	for words in data:
        # 각 라인을 group number, 탭, data 으로 출력한다.
		print('%s%s%f'%(words[0], separator, float(words[1])))

if __name__ == "__main__":
	main()
