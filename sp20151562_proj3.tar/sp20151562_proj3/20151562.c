#include "20151562.h"

int main()
{
	char userinput[100]; // 사용자가 입력한 문자열을 저장하는 변수
	char temparr[100]; // 임시적으로 배열을 받아 사용할 때 사용하는 변수
	char tempch[6][100];
	Node* tempnode = NULL, *tempnode2 = NULL, *tempnode3 = NULL; // 임시적으로 Node를 받을 때 사용하는 변수
	LinkedList hlist = {0, NULL, NULL}; // 사용자가 입력했던 문자열을 history 메뉴를 선택했을 시 보여주기위해 링크드 리스트를 통해 저장 및 관리하는 구조체
	int i, j, k; // 임시적인 변수
	DIR *dp; // 디렉토리를 열기위한 변수
	struct dirent *dent; // 디렉토리 정보를 저장하기 위한 변수
	struct stat sbuf; // 파일의 정보를 저장하기 위한 변수
	unsigned char memory[1048576]; // 메모리 공간
	int start, end, value; // dump, edit, fill 명령을 했을시 주소값과 저장할 값을 저장하는 변수
	int dumpadd = -1; // dump가 어디까지 출력했는지 저장하는 변수
	int which; // 어떤 명령을 선택했는지 저장하는 변수.
	Node* ophash[20]; // opcodelist를 저장하는 hashtable
	FILE *file, *fobj; // opcode.txt를 열기위한 변수
	Opcode *optemp = NULL; // Opcode 구조체를 저장하기 위한 임시변수
	Node* headsymbol = NULL; // symbol table의 링크드 리스트의 헤드를 저장하는 변수
	Symbol *symboltemp; // Symbol 구조체의 포인터를 임시적으로 저장하는 변수
	LinkedList asmline = {0, NULL, NULL}; // 각각의 어셈블 라인의 symbol, instruction, oeprand를 저장하는 링크드 리스트를 관리하는 변수
	Assembleline *tempasm = NULL; // Assembleline의 포인터를 임시적으로 저장하는 변수
	int address = 0; // pass1을 실행하는 중 각 줄을 실행했을 때 location count를 저장하는 변수
	int line = 0; // pass1, pass2를 각 실행할 때 현제 몇번째 줄을 하고 있는지의 값을 저장하는 변수
	int base = 0; // pass2를 실행할 때 base directive를 적었을 시 해당 base에 해당하는 주소값을 저장한다.
	char filename[20]; // 사용자가 assemble할 파일을 열 때 파일의 이름을 저장하는 변수
	int error = 0; // 해당 변수값이 1일시 에러가 있으며 0이면 에러가 없음.
	int progaddress = 0; // loader 또는 run 명령어를 수행할 때 시작하는 주소를 저장하는 변수입니다.
	int consecaddress = 0;
	LinkedList extsymtable = {0, NULL, NULL};
	ExtSymbol *tempextsym = NULL;
	int executeaddress = -1;
	LinkedList bplist = {0, NULL, NULL};
	int reg[9] = {0, };

	for (i = 0; i < 20; ++i) // 해쉬테이블의 배열을 모두 NULL값으로 초기화
		ophash[i] = NULL;
	if (!(file = fopen("opcode.txt", "r"))) // opcode.txt 파일 스트림 열기
	{
		puts("opcode open error!");
		return 1;
	}
	// opcode.txt를 열어 해시함수를 이용하여 해시테이블에 링크드리스트 형식으로 저장
	while(fscanf(file, "%s", userinput) != EOF)
	{
		optemp = (Opcode*)malloc(sizeof(Opcode));
		strcpy(optemp->num, userinput);
		fscanf(file, "%s", userinput);
		strcpy(optemp->name, userinput);
		fscanf(file, "%s", userinput);
		strcpy(optemp->form, userinput);
		tempnode = MakeNode((void*)optemp, (int)sizeof(Opcode));
		tempnode->nextnode = ophash[HashFunction(optemp->name)];
		ophash[HashFunction(optemp->name)] = tempnode;
	}
	fclose(file); // 해시테이블을 완성하고 파일스트림을 다시 닫는다.

	for (i = 0; i < 1048576; ++i) // 메모리 값을 모두 0으로 초기화
		memory[i] = 0;
	// 사용자의 입력에 따라 알맞은 실행을 quit 메뉴를 열기전까지 반복하는 반복문
	while (1)
	{
		fputs("sicsim> ", stdout);
		fgets(userinput, 100, stdin); // 사용자의 입력을 받는다.
		userinput[strlen(userinput)-1] = '\0'; // fgets를 통해 받으면 입력값의 마지막에 '\n'가 저장되기 때문에 이를 '\0'값으로 바꾸어준다.
		
		error = 0;
		which = WhichMenu(userinput, &start, &end, &value); // 함수 호출을 통해 which 변수에 해당 명령값을 저장한다.

		if (which == HELP) // help 명령시 실행. 어떤 명령이 있는지 알려준다.
		{
			puts("h[elp]");
			puts("d[ir]");
			puts("q[uit]");
			puts("hi[story]");
			puts("du[mp] [start, end]");
			puts("e[dit] address, value");
			puts("f[ill] start, end, value");
			puts("reset");
			puts("opcode mnemonic");
			puts("opcodelist");
			puts("assemble filename");
			puts("type filename");
			puts("symbol");
			puts("progaddr [address]");
			puts("loader [object filename1] [object filename2] [...]");
			puts("run");
			puts("bp [address]");
			
			InsertHistoryList(&hlist, userinput);
		}
		else if (which == QUIT) // quit 명령시 실행. 동적할당한 것을 모두 free해주고 반복문을 나간다.
		{
			if ((hlist.head))
				DeleteLinkedList(&(hlist.head));
			for (i = 0; i < 20; ++i)
				if (ophash[i])
				DeleteLinkedList(&ophash[i]);
			if (headsymbol)
				DeleteLinkedList(&headsymbol);
			if ((asmline.head))
				DeleteLinkedList(&(asmline.head));
			if ((extsymtable.head))
				DeleteLinkedList(&(hlist.head));
			if ((bplist.head))
				DeleteLinkedList(&(bplist.head));
			break;
		}
		else if (which == HISTORY) // HistoryList 구조체를 통해 수행한 명령어를 모두 출력
		{
			InsertHistoryList(&hlist, userinput);
			tempnode = hlist.head;
			for (j = 1; j <= hlist.count; ++j)
			{
				printf("%d : %s\n", j, (char*)(tempnode->val));
				tempnode = tempnode->nextnode;
			}
		}
		else if (which == DI) // dir 명령어를 실행. 실행파일에 있는 모든 파일을 출력하고 폴더의 끝에는 /를 실행파일의 끝에는 *를 붙여 출력한다.
		{
			if ((dp = opendir(".")) == NULL) // 실행파일이 있는 폴더를 연다.
			{
				perror("error!");
				break;
			}

			while ((dent = readdir(dp))) // 실행파일의 있는 폴더의 내용을 하나씩 읽는다.
			{
				printf("%s", dent->d_name);
				stat(dent->d_name, &sbuf); // 파일의 정보를 저장한다.

				if (S_ISDIR(sbuf.st_mode)) // 폴더일시 끝에 /를 붙인다.
						printf("/");
				else if (sbuf.st_mode & S_IEXEC) // 실행파일이시 끝에 '*'을 붙인다.
						printf("*");
				puts("");
			}

			closedir(dp);
			InsertHistoryList(&hlist, userinput);
		}
		else if (which == DUMP) // dump 명령어를 실행. start 혹은 end 변수의 값이 -1인 것은 사용자가 시작주소값과 끝주소값을 입력하지 않은 것을 의미한다.
		{
			if (start == -1) // 시작 주소값이 입력되지 않았으므로 마지막으로 출력한 값의 다음값으로 설정한다. 만약 해당 값이 메모리 범위를 넘으면 0으로 초기화한다.
			{
				start = dumpadd+1;
				if (start >= 1048576)
					start = 0;
			}
			if (end == -1) // 끝 주소값이 입력되지 않았으므로 시작 주소값에 159를 더해줌으로써 160개의 출력을 할 수 있게 해준다. end가 만약 메모리 범위를 넘으면 메모리의 마지막 값으로 초기화한다.
			{
				end = start + 159;
				if (end >= 1048576)
					end = 1048575;
			}

			k = start; // k는 세미콜론 뒤 해당 케릭터를 출력할 인덱스이다.

			printf("%04X0 ", start/16);
			for (j = start - (start%16); j < start; ++j) // 만약 시작주소값이 해당 라인의 첫번째 값이 아니라면 공백을 출력한다.
				printf("   ");
			while (start <= end) // start는 1씩 더해지며 메모리의 start 인덱스를 참조해 추력한다. k와는 별개로 움직이므로 주의한다.
			{
				printf("%02hhX ", memory[start]);
				if (!((start+1) % 16)) // 만약 start가 라인의 마지막 값이면 세미콜론을 붙이고 해당 라인의 케릭터 값을 출력한다.
				{
					fputs("; ", stdout);
					for (j = k - (k%16); j < k; ++j) // 만약 사용자가 입력한 시작값이 해당 라인의 첫번째 값이 아니라면 시작값의 전 값은'.'으로 출력한다.
						putchar('.');
					do // 해당 인덱스의 값이 0x20과 0x7E 값 사이라면 값을 출력하고 아니면 '.'을 출력한다.
					{
						if (memory[k] >= 0x20 && memory[k] <= 0x7E)
							putchar(memory[k]);
						else
							putchar('.');
						++k;
					} while (k % 16); // 라인을 모두 출력할때까지 반복한다.

					puts("");
					if ((start+1) <= end)
						printf("%04X0 ", start/16 + 1);
				}
				++start;
			}
			// 아래의 코드의 경우 사용자가 입력한 끝값이 라인의 마지막 값이 아니라면 마지막라인을 마저 출력해주는 코드이다.
			for (j = end; j < end + 15 - end%16; ++j) // 만약 사용자가 입력한 끝값이 해당 라인의 마지막 값이 아니라면 남은 값들을 공백으로 출력한다.
			{
				printf("   ");
				if (j+1 == (end + 15 - end%16))
					fputs("; ", stdout);
			}
			while (k <= end) // 마지막 라인의 출력이 끝나면 사용자가 입력한 끝값까지 해당 케릭터 값을 출력한다.
			{
				if (memory[k] >= 0x20 && memory[k] <= 0x7E)
					putchar(memory[k]);
				else
					putchar('.');
				++k;
			}
			while (k < end + 16 - end%16) // 사용자가 입력한 끝값의 다음값부터는 '.'으로 케릭터를 출력한다.
			{
				putchar('.');
				if (k+1 == (end + 16 - end%16))
					puts("");
				++k;
			}

			dumpadd = end;
			InsertHistoryList(&hlist, userinput);
		}
		else if (which == EDIT) //edit 명령어를 실행. 사용자가 입력한 주소에 입력한 값을 저장한다.
		{
			memory[start] = value;
			InsertHistoryList(&hlist, userinput);
			printf("edit commend is successfully done!\n");
		}
		else if (which == FILL) // 사용자가 입력한 주소값들 사이에 입력한 값을 저장한다.
		{
			for (i = start; i <= end; ++i)
				memory[i] = value;
			InsertHistoryList(&hlist, userinput);
			printf("fill commend is successfully done!\n");
		}
		else if (which == RESET) // 모든 메모리를 0으로 초기화한다.
		{
			for (i = 0; i < 0xFFFFF; ++i)
				memory[i] = 0;
			InsertHistoryList(&hlist, userinput);
			printf("reset commend is successfully done!\n");
		}
		else if (which == OPMNEMONIC) // 해당 mnemonic에 해당하는 opcode를 출력한다. WhichMenu가 이 명령어를 반환시 start에는 userinput 문자열에서 사용자가 입력한 mnemonic의 시작 주소값이 value에는 입력한 mnemonic의 길이가 저장된다.
		{
			if (value > 100) // temparr의 문자열의 길이가 100이므로 사용자가 입력한 mnemonic이 100자가 넘을 시 99자로 줄여준다.
				value = 99;
			strncpy(temparr, &userinput[start], value);
			temparr[value] = '\0';
			printf("temparr : %s\n", temparr);
			tempnode = ophash[HashFunction(temparr)]; // 사용자가 입력한 값을 해시함수에 넣어 해당하는 해시테이블에서 값을 찾는다.
			while (tempnode)
			{
				if (strcmp(temparr, ((Opcode*)(tempnode->val))->name) == 0)
				{
					printf("opcode is %s\n", ((Opcode*)(tempnode->val))->num);
					break;
				}
				tempnode = tempnode->nextnode;
			}
			InsertHistoryList(&hlist, userinput);
			if (!tempnode) // 만약 해당 해시테이블에서 값이 없을 시 출력
				printf("there is not mnemonic you input!\n");
		}
		else if (which == OPLIST) // 해시테이블에 저장된 opcodelist를 출력한다.
		{
			for (i = 0; i < 20; ++i)
			{
				printf("%2d : ", i);
				for (tempnode = ophash[i]; tempnode; tempnode = tempnode->nextnode)
				{
					printf("[%s, %s]", ((Opcode*)(tempnode->val))->name, ((Opcode*)(tempnode->val))->num);
					if (tempnode->nextnode)
						printf(" -> ");
				}
				puts("");
			}
			InsertHistoryList(&hlist, userinput);
		}
		else if (which == TYPE) // 사용자가 type을 입력했을 시 입력받은 파일을 열어 화면에 출력한다.
		{
			strncpy(temparr, &userinput[start], value);
			temparr[value] = '\0';

			if(!(file = fopen(temparr, "r"))) // 사용자가 입력받은 파일을 연다. 만약 해당 파일이 없을 시 에러 메세지를 출력한다.
				puts("file open error!");
			else
			{
				while (feof(file) == 0)
				{
					if (fgets(temparr, 99, file) == NULL)
						break;
					fputs(temparr, stdout);
				}
				fclose(file);
				puts("");
				InsertHistoryList(&hlist, userinput);
			}
		}
		else if (which == ASSEMBLE) // 사용자가 assemble을 요청시 해당 파일을 assemble하여 lst파일과 obj파일을 만든다.
		{
			strncpy(temparr, &userinput[start], value);
			temparr[value] = '\0';
			//사용자가 입력한 파일의 이름을 확장자만 제외하고 저장한다.
			for (i = 0; userinput[start+i] != '.'; ++i);
			strncpy(filename, &userinput[start], i);
			filename[i] = '\0';
			
			//pass1
			if (!(file = fopen(temparr, "r"))) // 해당 파일을 열고 파일이 없을시 에러메세지를 출력
				puts("file open error!");
			else
			{
				if (headsymbol)
					DeleteLinkedList(&headsymbol);
				line = 0;
				while (feof(file) == 0) // asm파일이 끝날 때 까지 계속 읽는다.
				{
					++line; // 각 줄을 읽을 때 마다 1씩 추가한다.

					fgets(temparr, 100, file);
					temparr[strlen(temparr)-1] = '\0';

					if (*temparr == '\0')
						continue;
					
					//각 줄의 정보를 저장할 Assemlbeline 변수를 동적할당하고 초기화한다.
					tempasm = (Assembleline*)malloc(sizeof(Assembleline));
					tempasm->address = -1;
					(tempasm->symbol)[0] = '\0';
					(tempasm->instruction)[0] = '\0';
					(tempasm->operand)[0] = '\0';
					tempasm->operand2 = '\0';
					tempasm->byte = -1;
					
					// 해당 문장이 주석일 경우 값을 저장하고 continue한다.
					if (temparr[0] == '.')
					{
						strcpy(tempasm->operand, temparr);
						tempnode = MakeNode((void*)tempasm, (int)sizeof(Assembleline));
						if (asmline.count == 0)
							asmline.head = tempnode;
						else
							(asmline.tail)->nextnode = tempnode;
						++asmline.count;
						tempnode->nextnode = NULL;
						asmline.tail = tempnode;
						continue;
					}

					// asm파일의 한줄을 저장한 문자열을 공백을 기준으로 6개의 문자열에 저장한다.
					// k에는 공백을 기준으로 잘랐을 때 몇개의 값이 들어왔는지 저장.
					for (i = 0; i < 6; ++i)
						tempch[i][0] = '\0';
					k = sscanf(temparr, "%s %s %s %s %s %s", tempch[0], tempch[1], tempch[2], tempch[3], tempch[4], tempch[5]);

					if (k == 6) // 6개의 값을 전해주는 경우는 없으므로 에러메세지 출력 후 반복문을 종료한다.
					{
						free(tempasm);
						printf("assemble error! %d line is incorrect.\n", line);
						DeleteLinkedList(&asmline.head);
						asmline.tail = NULL;
						asmline.count = 0;
						DeleteLinkedList(&headsymbol);
						error++;
						break;
					}
					else if (k == 1) // 한개의 값만 들어왔을 때
					{
						tempnode = FindOphash(tempch[0], ophash); // 저장한 값이 opcode table에 있는 값인지 확인
						if (tempnode) // 저장한 값이 opcode table에 있을 때
						{
							if ((((Opcode*)(tempnode->val))->form)[0] == '1') // 1 format의 경우 값을 저장
							{
								strcpy(tempasm->instruction, tempch[0]);
								tempasm->address = address;
								address += 1;
							}
							else if (strcmp(((Opcode*)(tempnode->val))->name, "RSUB") == 0) // RSUB의 경우 값을 저장
							{
								strcpy(tempasm->instruction, tempch[0]);
								tempasm->address = address;
								address += 3;
							}
							else // 1 format, RSUB instruction이 아닐 경우 에러메세지 출력
							{
								free(tempasm);
								printf("assemble error! %d line is incorrect.\n", line);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								error++;
								break;
							}

						}
						else if (strcmp(tempch[0], "END") == 0) // END directive 인 경우 값을 저장
						{
							strcpy(tempasm->instruction, tempch[0]);
							tempasm->address = address;
						}
						else // 나머지 경우 에러메세지 출력
						{
							free(tempasm);
							printf("assemble error! %d line is incorrect.\n", line);
							DeleteLinkedList(&asmline.head);
							asmline.tail = NULL;
							asmline.count = 0;
							DeleteLinkedList(&headsymbol);
							error++;
							break;
						}
					}
					else if (k == 2) // 공백 기준으로 2개의 값이 있을 경우
					{
						tempnode = FindOphash(tempch[1], ophash); // 공백 기준 뒤의 값이 opcode table에 instruction 인지 확인

						if (tempnode) // 공백 기준 2번째 값이 instruction인 경우
						{
							if ((((Opcode*)(tempnode->val))->form)[0] != '1' && strcmp(((Opcode*)(tempnode->val))->name, "RSUB") == 0)
							{
								free(tempasm);
								printf("assemble error! %d line is incorrect.\n", line);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								error++;
								break;
							}

							if ((((Opcode*)(tempnode->val))->form)[0] == '1') // instruction이 1 format인 경우 location counter를 1 올린다.
								j = 1;
							else // RSUB인 경우 location counter를 3 올린다.
								j = 3;

							tempnode = FindOphash(tempch[0], ophash);
							
							// 공백기준 첫번째 값이 instruction이거나 directive이면 에러 메세지 출력 
							if (tempnode)
							{
								printf("assemble error! %d line is error. symbol name can't be instruction name!", line);
								free(tempasm);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								error++;
								break;
							}
							if (FindDirective(tempch[0]))
							{
								printf("assemble error! %d line is error. symbol name can't be directive name!", line);
								free(tempasm);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								error++;
								break;
							}
							// 올바른 값일 경우 해당 값을 저장하고 location counter를 올린다.
							strcpy(tempasm->instruction, tempch[1]);
							strcpy(tempasm->symbol, tempch[0]);
							tempasm->address = address;
							address += j;
							// symbo table에 해당 값을 저장한다.
							symboltemp = (Symbol*)malloc(sizeof(Symbol));
							strcpy(symboltemp->name, tempch[0]);
							symboltemp->address = tempasm->address;
							tempnode = MakeNode((void*)symboltemp, (int)sizeof(Symbol));
							if (headsymbol == NULL)
								headsymbol = tempnode;
							else
							{
								for (tempnode2 = headsymbol; tempnode2->nextnode; tempnode2 = tempnode2->nextnode);
								tempnode2->nextnode = tempnode;
							}

						}
						else if (FindDirective(tempch[1])) // 공백기준 두번째 값이 directive인 경우
						{
							if (FindDirective(tempch[1]) == END) // END일 경우 값을 저장
							{
								strcpy(tempasm->instruction, tempch[1]);
								strcpy(tempasm->symbol, tempch[0]);

								symboltemp = (Symbol*)malloc(sizeof(Symbol));
								strcpy(symboltemp->name, tempch[0]);
								tempnode = MakeNode((void*)symboltemp, (int)sizeof(Symbol));
								if (headsymbol == NULL)
									headsymbol = tempnode;
								else
								{
									for (tempnode2 = headsymbol; tempnode2->nextnode; tempnode2 = tempnode2->nextnode);
									tempnode2->nextnode = tempnode;
								}
							}
							else // 해당 directive가 END가 아닐경우 operand가 필요한데 없으므로 에러메세지 출력
							{
								printf("assemble error! %d line is incorrect.\n", line);
								free(tempasm);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								error++;
								break;
							}
						}
						else // 공백 기준 두번째 값이 instructin, directive 둘 다 아닌경우
						{
							tempnode = FindOphash(tempch[0], ophash);

							if (tempnode) // 공백기준 첫번째 값이 instruction 인 경우
							{
								if ((((Opcode*)(tempnode->val))->form)[0] == '1') // 해당 instructinon이 1 format인 경우 operand가 없어야 하는데 있으므로 에러메세지 출력
								{
									free(tempasm);
									printf("assemble error! %d line is incorrect.\n", line);
									DeleteLinkedList(&asmline.head);
									asmline.tail = NULL;
									asmline.count = 0;
									DeleteLinkedList(&headsymbol);
									error++;
									break;
								}
								else if ((((Opcode*)(tempnode->val))->form)[0] == '2') // 해당 instructinon이 1 format인 경우
								{
									// CLEAR, SBC, TIXR의 경우 연산자를 하나만 받으므로 이를 처리한다.
									if (strcmp(((Opcode*)(tempnode->val))->name, "CLEAR") == 0 || strcmp(((Opcode*)(tempnode->val))->name, "SBC") == 0 || strcmp(((Opcode*)(tempnode->val))->name, "TIXR") == 0)
									{
										if (strlen(tempch[1]) > 1) // 올바른 레지스터 입력이 아닐 시 에러메세지 출력
										{
											printf("assemble error! %d line is incorrect.\n", line);
											free(tempasm);
											DeleteLinkedList(&asmline.head);
											asmline.tail = NULL;
											asmline.count = 0;
											DeleteLinkedList(&headsymbol);
											error++;
											break;
										}
										strcpy(tempasm->instruction, tempch[0]);
										strcpy(tempasm->operand, tempch[1]);
										tempasm->address = address;
										address += 2;
									}
									else
									{
										printf("assemble error! %d line is incorrect.\n", line);
										free(tempasm);
										DeleteLinkedList(&asmline.head);
										asmline.tail = NULL;
										asmline.count = 0;
										DeleteLinkedList(&headsymbol);
										error++;
										break;
									}
								}
								else // 해당 instructinon이 3 format인 경우
								{
									// RSUB의 경우 operand가 필요하지 않은데 oeprand가 있으니 에러메시지 출력
									if (strcmp(((Opcode*)(tempnode->val))->name, "RSUB") == 0)
									{
										printf("assmeble error! %d line is incorrect. RSUB doesn't need operand.\n", line);
										free(tempasm);
										DeleteLinkedList(&asmline.head);
										asmline.tail = NULL;
										asmline.count = 0;
										DeleteLinkedList(&headsymbol);
										error++;
										break;
									}
									strcpy(tempasm->instruction, tempch[0]);
									strcpy(tempasm->operand, tempch[1]);
									tempasm->address = address;
									if (tempch[0][0] == '+')
										address += 4;
									else
										address += 3;
								}
							}
							else if ((i = FindDirective(tempch[0]))) // 첫번째 입력값이 directive인 경우
							{
								strcpy(tempasm->instruction, tempch[0]);
								strcpy(tempasm->operand, tempch[1]);
								if (i == START) // 입력값이 start인 경우
								{
									tempasm->address = address;
									j = CheckConstant(tempch[1]);
										
									if (j > 0)
									{
										// operand가 16진수 혹은 10진수 숫자값인 경우 이를 저장 아닐경우 에러메세지 출력
										if (tempch[1][0] == 'X')
										{
											tempch[1][strlen(tempch[1])-1] = '\0';
											tempch[1][0] = '0';
											tempch[1][1] = 'x';

											address = strtol(tempch[1], NULL, 16);
										}
										else if (tempch[1][0] == 'C')
										{
											free(tempasm);
											printf("assemble error! %d line is incorrect.\n", line);
											DeleteLinkedList(&asmline.head);
											asmline.tail = NULL;
											asmline.count = 0;
											DeleteLinkedList(&headsymbol);
											error++;
											break;
										}
										else
											address = atoi(tempch[1]);
									}
									else
									{
										free(tempasm);
										printf("assemble error! %d line is incorrect.\n", line);
										DeleteLinkedList(&asmline.head);
										asmline.tail = NULL;
										asmline.count = 0;
										DeleteLinkedList(&headsymbol);
										error++;
										break;
									}
								}
								else if (i == BYTE) // 입력값이 BYTE인 경우 올바른 형식인지 확인
								{
									j = CheckConstant(tempch[1]);

									if (j < 0)
									{
										free(tempasm);
										printf("assemble error! %d line is incorrect.\n", line);
										DeleteLinkedList(&asmline.head);
										asmline.tail = NULL;
										asmline.count = 0;
										DeleteLinkedList(&headsymbol);
										error++;
										break;
									}
									tempasm->address = address;
									address += j;
								}
								else if (i == WORD) // 입력값이 WORD인 경우 올바른 형식인지 확인
								{
									j = CheckConstant(tempch[1]);

									if (j < 0)
									{
										free(tempasm);
										printf("assemble error! %d line is incorrect.\n", line);
										DeleteLinkedList(&asmline.head);
										asmline.tail = NULL;
										asmline.count = 0;
										DeleteLinkedList(&headsymbol);
										error++;
										break;
									}
									tempasm->address = address;
									address += 3;
								}
								else if (i == RESB) // 입력값이 RESB인 경우 올바른 형식인지 확인
								{
									tempasm->address = address;
									j = CheckConstant(tempch[1]);
										
									if (j > 0)
									{
										if (tempch[1][0] == 'X')
										{
											tempch[1][strlen(tempch[1])-1] = '\0';
											tempch[1][0] = '0';
											tempch[1][1] = 'x';

											address += strtol(tempch[1], NULL, 16);
										}
										else if (tempch[1][0] == 'C')
										{
											free(tempasm);
											DeleteLinkedList(&asmline.head);
											asmline.tail = NULL;
											asmline.count = 0;
											DeleteLinkedList(&headsymbol);
											printf("assemble error! %d line is incorrect.\n", line);
											error++;
											break;
										}
										else
											address += atoi(tempch[1]);
									}
									else
									{
										free(tempasm);
										printf("assemble error! %d line is incorrect.\n", line);
										DeleteLinkedList(&asmline.head);
										asmline.tail = NULL;
										asmline.count = 0;
										DeleteLinkedList(&headsymbol);
										error++;
										break;
									}
								}
								else if (i == RESW) // 입력값이 RESW인 경우 올바른 형식인지 확인
								{
									tempasm->address = address;
									j = CheckConstant(tempch[1]);
										
									if (j > 0)
									{
										if (tempch[1][0] == 'X')
										{
											tempch[1][strlen(tempch[1])-1] = '\0';
											tempch[1][0] = '0';
											tempch[1][1] = 'x';

											address += strtol(tempch[1], NULL, 16)*3;
										}
										else if (tempch[1][0] == 'C')
										{
											free(tempasm);
											printf("assemble error! %d line is incorrect.\n", line);
											DeleteLinkedList(&asmline.head);
											asmline.tail = NULL;
											asmline.count = 0;
											DeleteLinkedList(&headsymbol);
											error++;
											break;
										}
										else
											address += atoi(tempch[1])*3;
									}
									else
									{
										free(tempasm);
										printf("assemble error! %d line is incorrect.\n", line);
										DeleteLinkedList(&asmline.head);
										asmline.tail = NULL;
										asmline.count = 0;
										DeleteLinkedList(&headsymbol);
										error++;
										break;
									}
								}
							}
							else // 공백 기준 앞의 값, 뒤의 값 모두 directive와 instructoin이 아니면 에러메세지 출력
							{
								free(tempasm);
								printf("assemble error! %d line is incorrect.\n", line);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								error++;
								break;
							}
						}
					}
					else if (k >= 3) // 공백을 기준으로 나눴을 때 값이 3개 이상일 경우
					{
						tempnode = FindOphash(tempch[0], ophash);
						if (tempnode || FindDirective(tempch[0])) // 공백기준 첫번째의 값이 instruction이나 directive인 경우
						{
							// 두번째 값도 instruction이거나 directive 혹은 입력값이 5개인 경우는 에러 메세지 출력
							if ((tempnode = FindOphash(tempch[1], ophash)) != NULL || FindDirective(tempch[1]) || k == 5) 
							{
								free(tempasm);
								printf("asseble error! %d line 1is incorrect.\n", line);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								error++;
								break;
							}
							// tempch[1]에 instruction이 올 수 있도록 문자열을 하난씩 미뤄서 저장한다.
							for (i = 4; i >= 1; --i)
								strcpy(tempch[i], tempch[i-1]);
							tempch[0][0] = '\0';
							++k;
						}
						// tempasm 변수에 symbol과 instruction, location conter를 저장
						strcpy(tempasm->symbol, tempch[0]);
						strcpy(tempasm->instruction, tempch[1]);
						tempasm->address = address;

						if (k == 5) // 공백기준 입력값이 5개 인 경우 4번째 문자열에 ','이 들어오지 않은 경우 에러메세지 출력
						{
							if (tempch[3][0] == ',' && tempch[3][1] == '\0')
								strcpy(tempch[3], tempch[4]);
							else
							{
								printf("assemble error! %d line is incorrect.\n", line);
								free(tempasm);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								error++;
								break;
							}
						}
						else if (k == 4) // 공백기준 입력값이 4개가 들어온 경우 ','를 찾고 이름 지움. 없을 경우 에러메세지 출력
						{
							if (tempch[2][strlen(tempch[2])-1] == ',')
								tempch[2][strlen(tempch[2])-1] = '\0';
							else if (tempch[3][0] == ',')
								for (i = 0; i < strlen(tempch[3]); ++i)
									tempch[3][i] = tempch[3][i+1];
							else
							{
								printf("assemble error! %d line is incorrenct.\n", line);
								free(tempasm);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								error++;
								break;
							}
						}
						else // 공백 기준 입력값이 3개 들어올경우
						{
							// 만약 ','가 있을 시 이를 잘라서 따로 문자열에 저장한다.
							for (i = 0; i < strlen(tempch[2]); ++i)
								if (tempch[2][i] == ',')
								{
									tempch[2][i++] = '\0';
									strcpy(tempch[3], &tempch[2][i]);
									break;
								}
						}

						tempnode = FindOphash(tempch[1], ophash);

						if (tempnode) // 공백기준 첫번째 문자열이 instruction 인 경우
						{
							if ((((Opcode*)(tempnode->val))->form)[0] == '1') // instruction이 1format인 경우 에러메세지 출력
							{
								free(tempasm);
								printf("assemble error! %d line is incorrect.", line);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								error++;
								break;
							}
							else if ((((Opcode*)(tempnode->val))->form)[0] == '2') // 문자열이 2format인 경우
							{
								optemp = (Opcode*)(tempnode->val);
								// CLEAR, SBC, TIXR의 경우 operand가 2개 이상일 시 에러메세지 출력
								if (strcmp(optemp->name, "CLEAR") == 0 || strcmp(optemp->name, "SBC") == 0 || strcmp(optemp->name, "TIXR") == 0)
								{
									if (tempch[3][0] || strlen(tempch[2]) > 1)
									{
										free(tempasm);
										printf("assemble error! %d line is incorrect.\n", line);
										DeleteLinkedList(&asmline.head);
										asmline.tail = NULL;
										asmline.count = 0;
										DeleteLinkedList(&headsymbol);
										error++;
										break;
									}

									strcpy(tempasm->operand, tempch[2]);
									address += 2;
								}
								else // 나머지의 경우 operand가 2개 있을 시 이를 저장
								{
									if (tempch[3][0] == '\0' || strlen(tempch[3]) > 1 || strlen(tempch[2]) > 1)
									{
										free(tempasm);
										printf("assemble error! %d line is incorrect.\n", line);
										DeleteLinkedList(&asmline.head);
										asmline.tail = NULL;
										asmline.count = 0;
										DeleteLinkedList(&headsymbol);
										error++;
										break;
									}

									strcpy(tempasm->operand, tempch[2]);
									tempasm->operand2 = tempch[3][0];
									address += 2;
								}
							}
							else // instruction이 3, 4 fornmat인 경우
							{
								if (strcmp(((Opcode*)(tempnode->val))->name, "RUSB") == 0) // instruction이 RSUB인 경우 operand가 필요 없는데 입력값이 들어왔으므로 에러메세지 출력
								{
									printf("assemble error! %d line is incorrect. RSUB doesn't need operand.\n", line);
									free(tempasm);
									DeleteLinkedList(&asmline.head);
									asmline.tail = NULL;
									asmline.count = 0;
									DeleteLinkedList(&headsymbol);
									error++;
									break;
								}
								// 3 format instruction의 경우 operand가 2개 들어온 것은 x reg를 통해 저장할 경우이므로 해당 입력값이 맞는지 확인 후 아닐 경우 에러메세지 출력
								if (tempch[3][0]) 
								{
									if (tempch[3][0] == 'X' && strlen(tempch[3]) == 1)
										tempasm->operand2 = 'X';
									else
									{
										free(tempasm);
										printf("assemble error! %d line is incorrect.\n", line);
										DeleteLinkedList(&asmline.head);
										asmline.tail = NULL;
										asmline.count = 0;
										DeleteLinkedList(&headsymbol);
										error++;
										break;
									}
								}
								
								// operand가 instruction의 이름을 가질 경우 에러메시지 출력
								tempnode = FindOphash(tempch[2], ophash);
								if (tempnode || FindDirective(tempch[2]))
								{
									free(tempasm);
									printf("assemble error! %d line is incorrect.\n", line);
									DeleteLinkedList(&asmline.head);
									asmline.tail = NULL;
									asmline.count = 0;
									DeleteLinkedList(&headsymbol);
									error++;
									break;
								}

								strcpy(tempasm->operand, tempch[2]);
								
								//instruction의 format에 따라 location counter를 올림
								if (tempch[1][0] == '+')
									address += 4;
								else
									address += 3;
							}
						}
						else if ((i = FindDirective(tempch[1]))) // directive가 들어온 경우
						{
							// directive의 경우 operand가 2개 이상이면 에러메세지 출력
							if (tempch[3][0])
							{
								free(tempasm);
								printf("assemble error! %d line is incorrect.\n", line);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								error++;
								break;
							}
							
							if (i == START || i == RESB || i == RESW) // directive가 START, RESB, RESW인 경우 올바른 형식인지 확인 후 저장
							{
								j = CheckConstant(tempch[2]);
								if (j < 0 || tempch[2][0] == 'C')
								{
									free(tempasm);
									printf("assemble error! %d line is incorrect.\n", line);
									DeleteLinkedList(&asmline.head);
									asmline.tail = NULL;
									asmline.count = 0;
									DeleteLinkedList(&headsymbol);
									error++;
									break;
								}
								
								if (tempch[2][0] == 'X')
								{
									tempch[2][strlen(tempch[2])-1] = '\0';
									tempch[2][0] = '0';
									tempch[2][1] = 'x';

									j = strtol(tempch[2], NULL, 16)*3;
								}
								else
									j = atoi(tempch[2]);

								if (i == START)
									address = j;
								else if (i == RESB)
									address += j;
								else if (i == RESW)
									address += j*3;
							}
							else if (i == BYTE || i == WORD) // directive가 BYTE, WORD인 경우 올바른 형식인지 확인
							{
								j = CheckConstant(tempch[2]);
								if (j < 0)
								{
									free(tempasm);
									printf("assemble error! %d line is incorrect.\n", line);
									DeleteLinkedList(&asmline.head);
									asmline.tail = NULL;
									asmline.count = 0;
									DeleteLinkedList(&headsymbol);
									error++;
									break;
								}
								if (i == BYTE)
									address += j;
								else
									address += 3;
							}
							strcpy(tempasm->operand, tempch[2]);
						}
						else // instruction이나 directive가 없는 경우 에러메세지 출력
						{
							free(tempasm);
							printf("assemble error! %d line is incorrect.\n", line);
							DeleteLinkedList(&asmline.head);
							asmline.tail = NULL;
							asmline.count = 0;
							DeleteLinkedList(&headsymbol);
							error++;
							break;
						}
						
						// symbol값이 입력된 경우 이를 symbol table에 추가한다.
						if (tempch[0][0] != '\0' && i != START)
						{
							symboltemp = (Symbol*)malloc(sizeof(Symbol));
							strcpy(symboltemp->name, tempch[0]);
							symboltemp->address = tempasm->address;
							tempnode = MakeNode((void*)symboltemp, (int)sizeof(Symbol));
							if (headsymbol == NULL)
								headsymbol = tempnode;
							else
							{
								for (tempnode2 = headsymbol; tempnode2->nextnode; tempnode2 = tempnode2->nextnode);
								tempnode2->nextnode = tempnode;
							}
						}
					}

					// 현제 loaction counter와 현제 다루고 있는 명령어의 차를 통해 해당 명령어가 몇 byte인지 계산 후 저장한다.
					if (FindOphash(tempasm->instruction, ophash) || strcmp(tempasm->instruction, "BYTE") == 0 || strcmp(tempasm->instruction, "WORD") == 0)
						tempasm->byte = address - (tempasm->address);
					// 완성된 Assembleline 변수를 linked list에 추가한다.
					tempnode = MakeNode((void*)tempasm, (int)sizeof(Assembleline));
					if (asmline.count == 0)
						asmline.head = tempnode;
					else
						(asmline.tail)->nextnode = tempnode;
					++asmline.count;
					tempnode->nextnode = NULL;
					asmline.tail = tempnode;

				}
				fclose(file);

				if (error == 0)
					if (strcmp(((Assembleline*)((asmline.tail)->val))->instruction, "END") != 0)
				{
						free(tempasm);
						printf("assemble error! last line must be END directive.\n");
						DeleteLinkedList(&asmline.head);
						asmline.tail = NULL;
						asmline.count = 0;
						DeleteLinkedList(&headsymbol);
						error++;
					}
				
				//pass2
				line = 5;
				k = 0; // objectcode의 한 라인당 길이를 저장하는 값으로 0x1E가 넘으면 이를 obj 파일에 기록한다.
				
				//lst 파일와 obh파일을 연다.
				strcpy(temparr, filename);
				strcat(temparr, ".lst");
				file = fopen(temparr, "w");
				strcpy(temparr, filename);
				strcat(temparr, ".obj");
				fobj = fopen(temparr, "w");

				// Assembleline을 저장한 linkedlist에 있는 노드를 하나씩 읽으며 lst파일과 obj파일을 작성한다.
				for (tempnode = asmline.head; tempnode; tempnode = tempnode->nextnode)
				{
					i = 0; // i는 objectcode를 저장한다.
					
					// node를 읽어 lst 파일에 objectcode 전까지 입력한다.
					tempasm = (Assembleline*)(tempnode->val);
					fprintf(file, "%-8d", line);
					if (tempasm->address == -1)
						fprintf(file, "    \t\t");
					else
						fprintf(file, "%04X\t\t", tempasm->address);
					if ((tempasm->symbol)[0] == '\0')
						fprintf(file, "        \t\t");
					else
						fprintf(file, "%-8s\t\t", tempasm->symbol);
					if (tempasm->operand[0] != '.')
					{
						fprintf(file, "%-8s\t\t", tempasm->instruction);
						if ((tempasm->operand)[0] == '\0')
							fprintf(file, "              ");
						else if (tempasm->operand2)
						{
							fprintf(file, "%s, %c", tempasm->operand, tempasm->operand2);
							for (j = 0; j < 11-strlen(tempasm->operand); ++j)
								fprintf(file, " ");
						}
						else
							fprintf(file, "%-14s", tempasm->operand);
					}
					else
						fprintf(file, "%s", tempasm->operand);
					
					// objectcode를 계산한다.
					if ((tempnode2 = FindOphash(tempasm->instruction, ophash))) // 해당 라인이 instruction일 경우 opcode에 따라 objectcode 저장
					{
						optemp = ((Opcode*)(tempnode2->val));
						if ((optemp->form)[0] == '1') // 1형식일 경우
						{
							if ((optemp->num)[0] >= '0' && (optemp->num)[0] <= '9')
								i = (optemp->num[0] - '0') << 4;
							else
								i = (optemp->num[0] - 'A' + 10) << 4;
							
							if ((optemp->num)[1] >= '0' && (optemp->num)[1] <= '9')
								i += optemp->num[1] - '0';
							else
								i += optemp->num[1] - 'A' + 10;
						}
						else if ((optemp->form)[0] == '2') // 2형식인 경우 opcode와 register에 따라 objectcode 저장
						{
							if ((optemp->num)[0] >= '0' && (optemp->num)[0] <= '9')
								i = (optemp->num[0] - '0') << 12;
							else
								i = (optemp->num[0] - 'A' + 10) << 12;
							
							if ((optemp->num)[1] >= '0' && (optemp->num)[1] <= '9')
								i += (optemp->num[1] - '0') << 8;
							else
								i += (optemp->num[1] - 'A' + 10) << 8;

							if (strcmp(tempasm->operand, "X") == 0)
								i += 1 << 4;
							else if (strcmp(tempasm->operand, "L") == 0)
								i += 2 << 4;
							else if (strcmp(tempasm->operand, "B") == 0)
								i += 3 << 4;
							else if (strcmp(tempasm->operand, "S") == 0)
								i += 4 << 4;
							else if (strcmp(tempasm->operand, "T") == 0)
								i += 5 << 4;
							else if (strcmp(tempasm->operand, "F") == 0)
								i += 6 << 4;

							if (tempasm->operand2 != '\0')
							{
								if (tempasm->operand2 == 'X')
									i += 1;
								else if (tempasm->operand2 == 'L')
									i += 2;
								else if (tempasm->operand2 == 'B')
									i += 3;
								else if (tempasm->operand2 == 'S')
									i += 4;
								else if (tempasm->operand2 == 'T')
									i += 5;
								else if (tempasm->operand2 == 'F')
									i += 6;
							}
						}
						else // 3, 4 format instruction 인 경우
						{
							// instruction의 opcode에 따라 값을 저장
							if ((optemp->num)[0] >= '0' && (optemp->num)[0] <= '9')
								i = (optemp->num[0] - '0') << 20;
							else
								i = (optemp->num[0] - 'A' + 10) << 20;
							
							if ((optemp->num)[1] >= '0' && (optemp->num)[1] <= '9')
								i += ((optemp->num[1] - '0')) << 16;
							else
								i += (optemp->num[1] - 'A' + 10) << 16;

							if (tempasm->operand2 == 'X')
								i += 8 << 12;
							if (tempasm->instruction[0] == '+')
								i += 1 << 12;
							
							if (tempasm->operand[0] == '#')
								i += 1 << 16;
							else if (tempasm->operand[0] == '@')
								i += 2 << 16;
							else
								i += 3 << 16;
							
							if (strcmp(tempasm->instruction, "RSUB") == 0);
							// indirect, simple addressing 이거나 operand가 symbol값일 경우
							else if (CheckConstant(tempasm->operand+1) < 0 || tempasm->operand[0] != '#') 
							{
								// operend에 저장되있는 값을 이름으로 가진 symbol 값이 있는지 확인
								if (tempasm->operand[0] == '@' || tempasm->operand[0] == '#')
									for (tempnode2 = headsymbol; tempnode2; tempnode2 = tempnode2->nextnode)
									{
										if (strcmp(((Symbol*)(tempnode2->val))->name, tempasm->operand+1) == 0)
											break;
									}
								else
									for (tempnode2 = headsymbol; tempnode2; tempnode2 = tempnode2->nextnode)
									{
										if (strcmp(((Symbol*)(tempnode2->val))->name, tempasm->operand) == 0)
											break;
									}

								if (tempnode2 == NULL) // 없을 경우 에러메세지 출력
								{
									printf("assemble error! %d line is error!\n", line);
									DeleteLinkedList(&asmline.head);
									asmline.tail = NULL;
									asmline.count = 0;
									DeleteLinkedList(&headsymbol);
									remove(strcat(strcpy(temparr, filename), ".obj"));
									remove(strcat(strcpy(temparr, filename), ".lst"));
									++error;
									break;
								}
								if (tempasm->instruction[0] != '+') // instruction이 3형식일 경우
								{
									// PC relative방식을 사용가능할 경우 displacement를 저장
									j = ((Symbol*)(tempnode2->val))->address - tempasm->address - 3; 
									if (j <= 2047 && j >= -2048)
									{
										j = ((1 << 12) -1) & j;
										i += (2 << 12);
										i = i | j;
									}
									else if (base) // PC relative가 안될시 BASE relative가 가능한지 저장
									{
										j = ((Symbol*)(tempnode2->val))->address - base;
										if (j >= 0 && j<= 4095)
											i += j + (4 << 12);
										else if (((Symbol*)(tempnode2->val))->address <= 4095)
											i += ((Symbol*)(tempnode2->val))->address;
										else
										{
											printf("assemble error! %d line is error!\n", line);
											DeleteLinkedList(&asmline.head);
											asmline.tail = NULL;
											asmline.count = 0;
											DeleteLinkedList(&headsymbol);
											remove(strcat(strcpy(temparr, filename), ".obj"));
											remove(strcat(strcpy(temparr, filename), ".lst"));
											++error;
											break;
										}
									}
									else // 두경우 모두 안될시 에러메시지 출력
									{
										printf("assemble error! %d line is error!\n", line);
										DeleteLinkedList(&asmline.head);
										asmline.tail = NULL;
										asmline.count = 0;
										DeleteLinkedList(&headsymbol);
										remove(strcat(strcpy(temparr, filename), ".obj"));
										remove(strcat(strcpy(temparr, filename), ".lst"));
										++error;
										break;
									}
								}
								else// instruction이 4형식일 경우 이를 저장
								{
									i = i << 8;
									i += ((Symbol*)(tempnode2->val))->address;
								}
							}
							else // operand에 10진수 혹은 16진수 혹은 character형식으로 값이 저장되어 있을 경우
							{
								if (tempasm->operand[0] == '#' || tempasm->operand[0] == '@')
									j = 1;
								else
									j = 0;
								if (tempasm->operand[j] == 'C') // character 형식일 경우 에러메세지 출력
								{
									printf("assemble error! %d line is error!\n", line);
									DeleteLinkedList(&asmline.head);
									asmline.tail = NULL;
									asmline.count = 0;
									DeleteLinkedList(&headsymbol);
									remove(strcat(strcpy(temparr, filename), ".obj"));
									remove(strcat(strcpy(temparr, filename), ".lst"));
									++error;
									break;
								}
								else // 16진수나 10진수 값이 들어왔을시 이를 저장
								{
									if (tempasm->operand[j] == 'X')
									{
										tempasm->operand[j] = '0';
										tempasm->operand[j+1] = 'x';
										tempasm->operand[strlen(tempasm->operand)-1] = '\0';

										j = strtol(tempasm->operand+j, NULL, 16);
									}
									else
										j = atoi(tempasm->operand+j);

									if (tempasm->instruction[0] != '+')
									{
										if (j >= 0 && j <= 4095)
											i += j;
										else
										{
											printf("assemble error! %d line is error!\n", line);
											DeleteLinkedList(&asmline.head);
											asmline.tail = NULL;
											asmline.count = 0;
											DeleteLinkedList(&headsymbol);
											remove(strcat(strcpy(temparr, filename), ".obj"));
											remove(strcat(strcpy(temparr, filename), ".lst"));
											++error;
											break;
										}
									}
									else
									{
										i = i << 8;
										if (j >= 0 && j < (2 << 20))
											i += j;
										else
										{
											printf("assemble error! %d line is error!\n", line);
											DeleteLinkedList(&asmline.head);
											asmline.tail = NULL;
											asmline.count = 0;
											DeleteLinkedList(&headsymbol);
											remove(strcat(strcpy(temparr, filename), ".obj"));
											remove(strcat(strcpy(temparr, filename), ".lst"));
											++error;
											break;
										}
									}
								}
							}
						}
					}
					// 해당라인이 BYTE와 WORD인 경우
					else if(FindDirective(tempasm->instruction) == BYTE || FindDirective(tempasm->instruction) == WORD)
					{
						if (CheckConstant(tempasm->operand) < 0) // operand가 16진수, 10진수 character가 아닐 시 에러메세지 출력
						{
							printf("assemble error! %d line is error!\n", line);
							DeleteLinkedList(&asmline.head);
							asmline.tail = NULL;
							asmline.count = 0;
							DeleteLinkedList(&headsymbol);
							remove(strcat(strcpy(temparr, filename), ".obj"));
							remove(strcat(strcpy(temparr, filename), ".lst"));
							++error;
							break;
						}
						// 방식에 따른 적절한 값 저장.
						if (tempasm->operand[0] == 'X')
						{
							tempasm->operand[0] = '0';
							tempasm->operand[1] = 'x';
							tempasm->operand[strlen(tempasm->operand)-1] = '\0';

							j = strtol(tempasm->operand, NULL, 16);
						}
						else if (tempasm->operand[0] == 'C')
						{
							if (strlen(tempasm->operand) > 7)
							{
								printf("assemble error! %d line is error! Too long character string.\n", line);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								remove(strcat(strcpy(temparr, filename), ".obj"));
								remove(strcat(strcpy(temparr, filename), ".lst"));
								++error;
								break;
							}
							j = 0;
							for (int l = 0; l < strlen(tempasm->operand)-3; ++l)
								j += tempasm->operand[strlen(tempasm->operand)-l-2] << (l*8);
						}
						else
						{
							printf("assemble error! %d line is error!\n", line);
							DeleteLinkedList(&asmline.head);
							asmline.tail = NULL;
							asmline.count = 0;
							DeleteLinkedList(&headsymbol);
							remove(strcat(strcpy(temparr, filename), ".obj"));
							remove(strcat(strcpy(temparr, filename), ".lst"));
							++error;
							break;
						}

						i += j;
							
					}
					else if (FindDirective(tempasm->instruction) == BASE) // 해당라인이 BASE인 경우 operand의 값을 base 변수에 저장한다.
					{
						if (CheckConstant(tempasm->operand) < 0)
						{
							for (tempnode2 = headsymbol; tempnode2; tempnode2 = tempnode2->nextnode)
								if (strcmp(((Symbol*)(tempnode2->val))->name, tempasm->operand) == 0)
										break;
							if (tempnode2)
								base = ((Symbol*)(tempnode2->val))->address;
							else
							{
								printf("assemble error! %d line is error!\n", line);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								remove(strcat(strcpy(temparr, filename), ".obj"));
								remove(strcat(strcpy(temparr, filename), ".lst"));
								++error;
								break;
							}
						}
						else
						{
							if (tempasm->operand[0] == 'X')
							{
								tempasm->operand[0] = '0';
								tempasm->operand[1] = 'x';
								tempasm->operand[strlen(tempasm->operand)-1] = '\0';

								j = strtol(tempasm->operand, NULL, 10);
							}
							else if (tempasm->operand[0] == 'C')
							{
								printf("assemble error! %d line is error!\n", line);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								remove(strcat(strcpy(temparr, filename), ".obj"));
								remove(strcat(strcpy(temparr, filename), ".lst"));
								++error;
								break;
							}
							else
								j = atoi(tempasm->operand);

							base = j;
						}
					}
					// 아직 obj파일에 입력을 하지 않았을 시 START directive일 경우 해당 값에 따른 이름과 시작주소를 obj파일에 적는다.
					if (ftell(fobj) == SEEK_SET) 
					{
						fprintf(fobj, "H");
						if (strcmp(tempasm->instruction, "START") == 0)
						{
							fprintf(fobj, "%-6s", tempasm->symbol);
							fprintf(fobj, "%06X", atoi(tempasm->operand));
							fprintf(fobj, "%06X", address - atoi(tempasm->operand));
						}
						else
						{
							fprintf(fobj, "      ");
							fprintf(fobj, "%06X", 0);
							fprintf(fobj, "%06X", address);
						}
						fprintf(fobj, "\n");
						k = 0;
					}
					// *k의 값은 각 라인당 text record에서 starting address다음부터 적힐 objectcode가 현제 몇바이트 저장되어 있는지를 의미
					if (k == 0) // obj file의 text recode에서 해당 줄의 시작 address를 적어야 하므로 이를 end 변수에 저장한다.
						end = tempasm->address;
					// 해당 라인의 objectcode를 저장할 시 0x1E byte가 넘을시 이를 obj파일에 입력한다.
					if ((tempasm->byte > 0 && tempasm->byte + k > 0x1E) || ((strcmp(tempasm->instruction, "RESB") == 0 || strcmp(tempasm->instruction, "RESW") == 0) && k != 0))
					{
						fprintf(fobj, "T%06X%02X", end, k);
						for (j = 0; j < k; ++j)
							fprintf(fobj, "%02hhX", tempch[0][j]);

						fprintf(fobj, "\n");
						k = 0;
					}
					// byte에 따라 저장한 objectcode를 lst파일에 입력하고 obj파일에 입력할 값을 저장중인 tempch[0] 배열에 저장한다.
					if (tempasm->byte == 1)
					{
						tempch[0][k++] = (char)i;
						fprintf(file , "%02X\n", i);
					}
					else if (tempasm->byte == 2)
					{
						for (j = 1; j >= 0; --j)
							tempch[0][k++] = (char)(i >> (j*8));
						fprintf(file , "%04X\n", i);
					}
					else if (tempasm->byte == 3)
					{
						for (j = 2; j >= 0; --j)
							tempch[0][k++] = (char)(i >> (j*8));
						fprintf(file , "%06X\n", i);
					}
					else if (tempasm->byte == 4)
					{
						for (j = 3; j >= 0; --j)
							tempch[0][k++] = (char)(i >> (j*8));
						fprintf(file , "%08X\n", i);
					}
					else
						fprintf(file, "\n");

					line += 5;
				}
				 
				if (error == 0) // error가 없을 시
				{
					// 반복문이 끝났지만 아직 obj파일에 적지않고 저장되어있는 tempch[0]의 값을 적는다.
					fprintf(fobj, "T%06X%02X", end, k);
					for (j = 0; j < k; ++j)
						fprintf(fobj, "%02hhX", tempch[0][j]);

					fprintf(fobj, "\n");

					//modification을 수행한다.
					if (strcmp(((Assembleline*)(asmline.head)->val)->instruction, "START") == 0)
						j = ((Assembleline*)(asmline.head)->val)->address;
					else
						j = 0;

					for (tempnode = asmline.head; tempnode; tempnode = tempnode->nextnode)
						if (((Assembleline*)(tempnode->val))->instruction[0] == '+')
						{
							if (((Assembleline*)(tempnode->val))->operand[0] == '#')
								if (CheckConstant(&(((Assembleline*)(tempnode->val))->operand[1])) > 0)
										continue;
							fprintf(fobj, "M%06X%02X\n", ((Assembleline*)(tempnode->val))->address + 1 - j, 5);
						}
	
					// obj파일의 마지막줄에 적을 end record를 적는다.
					fprintf(fobj, "E");
					for (tempnode = asmline.head; tempnode; tempnode = tempnode->nextnode)
						if (strcmp(((Assembleline*)(tempnode->val))->instruction, "END") == 0)
						{
							tempasm = (Assembleline*)(tempnode->val);
							if (tempasm->operand[0] == '\0')
								break;
	
							for (tempnode2 = headsymbol; tempnode2; tempnode2 = tempnode2->nextnode)
								if (strcmp(((Symbol*)(tempnode2->val))->name, tempasm->operand) == 0)
								{
									fprintf(fobj, "%06X", ((Symbol*)(tempnode2->val))->address);
									break;
								}
							if (tempnode2 == NULL)
							{
								printf("assemble error! %d line is error!\n", line);
								DeleteLinkedList(&asmline.head);
								asmline.tail = NULL;
								asmline.count = 0;
								DeleteLinkedList(&headsymbol);
								remove(strcat(strcpy(temparr, filename), ".obj"));
								remove(strcat(strcpy(temparr, filename), ".lst"));
								error++;
							}
							break;
						}
				}
				// error가 없을 시 lst파일과 obj파일이 만들어 졌음을 알린다.
				if (error == 0)
					printf("outputfile : [%s.lst], [%s.obj]\n", filename,filename);
				fclose(fobj);
				fclose(file);
				InsertHistoryList(&hlist,userinput);
			}
			if (asmline.head)
				DeleteLinkedList(&asmline.head);
			asmline.tail = NULL;
			asmline.count = 0;
			// headsymbol 내림차순 정렬
			if (headsymbol)
			{
				k = 0;
				for (tempnode = headsymbol; tempnode; tempnode = tempnode->nextnode)
					++k;

				for (i = k-1; i >= 1; --i)
				{
					tempnode = headsymbol;
					tempnode2 = tempnode->nextnode;
					if (tempnode2 == NULL)
						break;

					for (j = 0; j < i; ++j)
					{
						if (strcmp(((Symbol*)(tempnode->val))->name, ((Symbol*)(tempnode2->val))->name) < 0)
						{
							if (tempnode == headsymbol)
							{
								tempnode->nextnode = tempnode2->nextnode;
								tempnode2->nextnode = tempnode;
								headsymbol = tempnode2;
							}
							else
							{
								tempnode->nextnode = tempnode2->nextnode;
								tempnode2->nextnode = tempnode;
								tempnode3->nextnode = tempnode2;
							}
							tempnode3 = tempnode2;
							tempnode2 = tempnode;
							tempnode = tempnode3;
						}
							tempnode3 = tempnode;
							tempnode = tempnode->nextnode;
							tempnode2 = tempnode2->nextnode;
					}
				}
			}
		}
		else if (which == SYMBOL) // assmeble 과정에 생성된 symbol table의 값을 출력한다.
		{
			for (tempnode = headsymbol; tempnode; tempnode = tempnode->nextnode)
			{
				printf("\t%s\t%04X\n", ((Symbol*)(tempnode->val))->name, ((Symbol*)(tempnode->val))->address);
			}
			InsertHistoryList(&hlist,userinput);
		}
		else if (which == PROGADDR) // loader 또는 run 명령어를 수행할 때 시작하는 주소를 지정. default value 는 0입니다.
		{
			progaddress = value;
			puts("program address is successfully saved!");
			InsertHistoryList(&hlist,userinput);
		}
		else if (which == LOADER) // 사용자가 linking loader를 요청할 시 이를 실행하는 조건문
		{
			// 만약 External Symbol table이 있을 시 이를 지우고 다시 만든다.
			if (extsymtable.head)
			{
				DeleteLinkedList(&(extsymtable.head));
				extsymtable.head = NULL;
				extsymtable.tail = NULL;
				extsymtable.count = 0;
			}
			//pass1
			// temparr에 첫번째 파일의 이름을 저장하고 pass1을 실행한다. consecaddress는 해당 control section의 첫 주소를 의미한다.
			j = 0;
			for (i = start; userinput[i] != '\0' && userinput[i] != '\n' && userinput[i] != ' '; ++i)
				temparr[j++] = userinput[i];
			temparr[j] = '\0';
			consecaddress = progaddress;
			consecaddress = LinkPass1(temparr, &extsymtable, consecaddress);
			if (consecaddress == -1) // 반환 값이 -1이란 말은 오류가 발생했다는 것이므로 뒷 부분을 생략한다.
				continue;


			if (end != -1) // 두번째 파일도 있을 경우
			{
				j = 0;
				for (i = end; userinput[i] != '\0' && userinput[i] != '\n' && userinput[i] != ' '; ++i)
					temparr[j++] = userinput[i];
				temparr[j] = '\0';
				consecaddress = LinkPass1(temparr, &extsymtable, consecaddress);
				if (consecaddress == -1)
					continue;

				if (value != -1) // 세번째 파일도 있을 경우
				{
					j = 0;
					for (i = value; userinput[i] != '\0' && userinput[i] != '\n' && userinput[i] != ' '; ++i)
						temparr[j++] = userinput[i];
					temparr[j] = '\0';
					consecaddress = LinkPass1(temparr, &extsymtable, consecaddress);
					if (consecaddress == -1)
						continue;
				}
			}

			// pass2
			// pass1과 마찬가지로 temparr에 파일의 이름을 저장하고 loading한다.
			j = 0;
			for (i = start; userinput[i] != '\0' && userinput[i] != '\n' && userinput[i] != ' '; ++i)
				temparr[j++] = userinput[i];
			temparr[j] = '\0';
			executeaddress = LinkPass2(temparr, &extsymtable, memory); // 실행할 주소 값을 반환 받는다.
			if (executeaddress == -1) // 
				continue;

			if (end != -1) // 두번째 파일이 있는 경우
			{
				j = 0;
				for (i = end; userinput[i] != '\0' && userinput[i] != '\n' && userinput[i] != ' '; ++i)
					temparr[j++] = userinput[i];
				temparr[j] = '\0';
				k = LinkPass2(temparr, &extsymtable, memory);
				if (k == -1)
					continue;
				if (executeaddress == -1)
					executeaddress = k;

				if (value != -1) // 세번째 파일이 있는 경우
				{
					j = 0;
					for (i = value; userinput[i] != '\0' && userinput[i] != '\n' && userinput[i] != ' '; ++i)
						temparr[j++] = userinput[i];
					temparr[j] = '\0';
					k = LinkPass2(temparr, &extsymtable, memory);
					if (k == -1)
						continue;
					if (executeaddress == -1)
						executeaddress = k;
				}
			}

			// external symbol table 을 출력한다.
			puts("control\t\tsymbol\t\taddress\t\tlength");
			puts("section\t\tname");
			puts("-----------------------------------------------------------------------------");
			for (tempnode = extsymtable.head; tempnode; tempnode = tempnode->nextnode)
			{
				tempextsym = (ExtSymbol*)(tempnode->val);

				if (tempextsym->length != -1)
					printf("%s\t\t\t\t%06X\t\t%06X\n", tempextsym->name, tempextsym->address, tempextsym->length);
				else
					printf("\t\t%s\t\t%06X\n", tempextsym->name, tempextsym->address);
			}
			puts("-----------------------------------------------------------------------------");
			printf("\t\t\t\ttotal length\t%X\n", consecaddress - progaddress);
		}
		else if (which == RUN) // program을 설정한 progaddress부터 실행한다.
		{
			// 프로그램의 전체 길이를 i에 저장
			i = 0;
			for (tempnode = extsymtable.head; tempnode; tempnode = tempnode->nextnode)
				if (((ExtSymbol*)(tempnode->val))->length >= 0)
					i += ((ExtSymbol*)(tempnode->val))->length; 
			RunProgram(memory, progaddress, &bplist, reg, i);
		}
		else if (which == BP) // run을 수행할 때 멈춘 break point설정한다.
		{
			if (start == 1) // bp clear를 입력한 경우
			{
				if (bplist.count)
					DeleteLinkedList(&(bplist.head));
				bplist.head = NULL;
				bplist.tail = NULL;
				bplist.count = 0;
			}
			else if (value != -1) // bp [address] 입력한 경우
			{
				tempnode = (Node*)malloc(sizeof(Node));
				tempnode->val = malloc(sizeof(int));
				*(int*)(tempnode->val) = value;
				tempnode->nextnode = NULL;

				if (bplist.count == 0)
					bplist.head = tempnode;
				else
					bplist.tail->nextnode = tempnode;
				bplist.tail = tempnode;
				bplist.count++;

				printf("[ok] create breakpoint %X\n", value);
			}
			else // bp만 입력한 경우
			{
				puts("breakpoint\n----------");
				for (tempnode = bplist.head; tempnode; tempnode = tempnode->nextnode)
					printf("%X\n", *(int*)(tempnode->val));
			}
		}
		else
			printf("commend error! check you input.\n");
	}

	return 0;
}


Node* MakeNode(void* input, int size) // Node를 만들어 주는 함수. input값은 저장할 값의 주소값, size값은 input값의 바이트 크기. Node의 성분인 보이드형 포인트 변수인 val에 동적할당을 하고 memcpy 함수를 동해 메모리를 복사한다.
{
	Node* tempnode = (Node*)malloc(sizeof(Node));

	tempnode->val = malloc(size);
	tempnode->nextnode = NULL;

	memcpy(tempnode->val, input, size);

	return tempnode;
}
int WhichMenu(char* input, int *start, int *end, int *value) // 어떤 명령을 호출했는지 반환해주며 올바르지 않는 명령의 경우 -1를 반환해 무시하도록 한다. start, end, value를 받아 명령어에 따라 올바른 값을 저장.
{
	char testarr[100]; // input 매개변수의 값을 복사해 받는데 사용한다.
	char *token; // strtok함수를 사용할 때 반환 값을 저장하는 변수.
	int which = -1; // 어떤 명렁어를 호출 했는지 저장하는 변수
	int i, j, k; // 임시 정수 변수.
	char* temp, *temp1; // dump, edit, fill의 경우 ','의 위치를 저장하여 올바른 위치에 있는지 확인.

	if (input[0] == '\0') // 입력값의 없을시 -1을 반환
		return -1;
	// start, end, value 값을 모두 -1로 초기화
	*start = -1;
	*end = -1;
	*value = -1;

	strcpy(testarr, input);

	token = strtok(testarr, " \t"); // 문자열을 탭이나 뛰어쓰기 기준으로 자른다.

	if (strcmp(token, "h") == 0|| strcmp(token, "help") == 0) // 사용자가 help 명령을 올바르게 호출했으면 which에 HELP값을 저장한다.
	{
		if (!(token = strtok(NULL, " \t")))
			which = HELP;
	}
	else if (strcmp(token, "d") == 0|| strcmp(token, "dir") == 0) // 사용자가 dir 명령을 올바르게 호출했으면 which에 DI값을 저장한다.
	{
		if (!(token = strtok(NULL, " \t")))
			which = DI;
	}
	else if (strcmp(token, "q") == 0|| strcmp(token, "quit") == 0) // 사용자가 quit 명령을 올바르게 호출했으면 which에 QUIT값을 저장한다.
	{
		if (!(token = strtok(NULL, " \t")))
			which = QUIT;
	}
	else if (strcmp(token, "hi")  == 0|| strcmp(token, "history") == 0) // 사용자가 history 명령을 올바르게 호출했으면 which에 HISTORY값을 저장한다.
	{
		if (!(token = strtok(NULL, " \t")))
			which = HISTORY;
	}	
	else if (strcmp(token, "du") == 0|| strcmp(token, "dump") == 0) // 사용자가 dump 명령어를 올바르게 호출하면 which에 DUMP값을 저장하고 시작값을 입력했다면 start에 끝값을 입력했다면 end에 저장한다.
	{
		if ((token = strtok(NULL, " \t"))) // dump뒤에 더 입력한 문자열이 있는지 확인
		{
			temp = NULL;
			// strtok 호출하면 token화 하면서 testarr의 중간중간에 '\0'이 넣어지기 때문에 입력문자열을 다시 testarr에 저장하고 strtok를 다시 호출함으로써 token에 du나 dump의 첫번째 주소값이 저장되게 한다.
			// 또한 strtok가 토큰화하기 위해 저장한 '\0'값 뒤에 다음 값이 있음을 알고 있으므로 해당 값 뒤에 ','값이 있는지 확인하고 있을 시 temp에 첫번째 ','의 위치값을 저장한다.
			// 해당 ','주소값에 ' '를 저장해 strtok를 통해 ','값 앞과 뒤가 token화 되게 한다.
			strcpy(testarr, input);
			token = strtok(testarr, " \t");
			for (i = 1; *(token + strlen(token) +i) != '\0'; ++i)
				if (*(token + strlen(token)+i) == ',')
				{
					*(token+strlen(token)+i) = ' ';
					temp = token + strlen(token) +i;
					break;
				}
			
			if (!(token = strtok(NULL, " \t"))) // strtok에는 더이상 token화 할게 없으면 NULL문자를 반환한다. 만약 dump 명령어 뒤에 ','한자만 있을시 앞서 ' '로 바뀜으로써 토큰화 할게 없어 NULL를 반환하는데 이때 -1를 반환한다.
				return -1;
			if (temp && (temp < token)) // temp의 주소값이 token의 주소값 즉, 시작값보다 앞에 있을시 잘못된 입력이므로 -1을 반환한다. ex) du ,1
				return -1;
			// 시작값의 문자열 값만 샌다. 이때 값은 숫자나 대소문자 a부터 f까지 값만 인정한다.
			for (i = 0; (token[i] >= '0' && token[i] <= '9') || (token[i] >= 'a' && token[i] <= 'f') || (token[i] >= 'A' && token[i] <= 'Z'); ++i);

			if (token[i] == '\0') // 시작값에 16진수에 해당하는 문자만 있으면 if문 안에 들어간다.
			{
				if (strlen(token) > 6) // 너무 긴 시작값의 경우 메모리값을 초과하므로 -1을 반환
					return -1;
				//시작주소값을 start에 저장
				*start = 0;
				k = 1;
				for (i-=1; i >=0; --i)
				{
					if (token[i] >= '0' && token[i] <= '9')
						*start = *start + k * (token[i] - '0');
					else if (token[i] >= 'a' && token[i] <= 'z')
						*start = *start + k * (token[i] + 10 - 'a');
					else
						*start = *start + k * (token[i] + 10 - 'A');
					k *= 16;
				}
				
				if (*start >= 1048576) // start의 값이 메모리 범위를 벗어나면 -1 반환
					return -1;
				
				if ((token = strtok(NULL, " \t"))) // 시작값 뒤에도 입력한 문자열이 있을시 들어간다.
				{
					if (!temp || token < temp) // temp의 값이 NULL일 경우 즉, ','의 값이 없었거나 temp의 주소값이 끝값의 시작주소보다 뒤에 있을 시 잘못된 입력이므로 -1을 반환
						return -1;
					for (i = 0; (token[i] >= '0' && token[i] <= '9') || (token[i] >= 'a' && token[i] <= 'f') || (token[i] >= 'A' && token[i] <= 'Z'); ++i);

					if (token[i] == '\0') // 끝값을 저장한다.
					{
						if (strlen(token) > 7)
							return -1;
						*end = 0;
						k = 1;
						for (i -= 1; i >=0; --i)
						{
							if (token[i] >= '0' && token[i] <= '9')
								*end = *end + k * (token[i] - '0');
							else if (token[i] >= 'a' && token[i] <= 'z')
								*end = *end + k * (token[i] + 10 - 'a');
							else
								*end = *end + k * (token[i] + 10 - 'A');
							k *= 16;
						}

						if (*end < *start || *end >= 1048576)
							return -1;
						if ((token = strtok(NULL, " \t"))) // 끝값 뒤에도 입력한 문자열이 있으면 잘못된 문자열이므로 -1을 반환
								return -1;
						which = DUMP;
					}
				}
				else // 끝값을 입력하지 않았을시
				{
					if (temp) // 끝값을 입력하지 않았으나 ','가 있으면 잘못된 입력이므로 -1을 반환
						return -1;
					which = DUMP;
				}
			}

		}
		else // dump만 입력했을 시
			which = DUMP;
		
	}
	else if (strcmp(token, "e") == 0|| strcmp(token, "edit") == 0) // 사용자가 edit 명령을 올바르게 호출하면 which에 EDIT을 저장하고 start 변수에 주소값을 value 변수에 저장할 값을 저장한다.
	{
		// 예외처리 및 저장방식은 위의 dump와 동일하다.
		if ((token = strtok(NULL, " \t")))
		{
			strcpy(testarr, input);
			token = strtok(testarr, " \t");
			temp = NULL;
			for (i = 1; *(token + strlen(token) +i) != '\0'; ++i)
				if (*(token + strlen(token)+i) == ',')
				{
					*(token+strlen(token)+i) = ' ';
					temp = token + strlen(token)+i;
					break;
				}
			
			if (!(token = strtok(NULL, " \t")))
				return -1;

			if (temp == NULL || temp < token)
				return -1;

			for (i = 0; (token[i] >= '0' && token[i] <= '9') || (token[i] >= 'A' && token[i] <= 'F') || (token[i] >= 'a' && token[i] <= 'f'); ++i);


			if (token[i] == '\0')
			{
				if (strlen(token) > 6)
					return -1;
				*start = 0;
				k = 1;
				for (i-=1; i >=0; --i)
				{
					if (token[i] >= '0' && token[i] <= '9')
						*start += k * (token[i] - '0');
					else if(token[i] >= 'a' && token[i] <= 'z')
						*start += k * (token[i] - 'a' + 10);
					else
						*start += k * (token[i] - 'A' + 10);
					k *= 16;
				}
				
				if (*start >= 0xFFFFF)
					return -1;

				if ((token = strtok(NULL, " \t")))
				{
					if (temp > token)
						return -1;
					for (i = 0; (token[i] >= '0' && token[i] <= '9') || (token[i] >= 'A' && token[i] <= 'F') || (token[i] >= 'a' && token[i] <= 'f'); ++i);

					if (token[i] == '\0')
					{
						if (strlen(token) > 2)
							return -1;
						*value = 0;
						k = 1;
						for (i -= 1; i >= 0; --i)
						{
							if (token[i] >= '0' && token[i] <= '9')
								*value += k * (token[i] - '0');
							else if(token[i] >= 'a' && token[i] <= 'z')
								*value += k * (token[i] - 'a' + 10);
							else
								*value += k * (token[i] - 'A' + 10);
							k *= 16;
						}
						which = EDIT;
					}
				}
			}
		}
	}
	else if (strcmp(token, "f") == 0 || strcmp(token, "fill") == 0) // 사용자가 fill 명령어를 올바르게 호출시 which에 FILL을 저장하고 start에는 시작값을 end에는 끝값을 value에는 저장할 값을 저장한다.
	{
		// 예외처리 및 저장방식은 위의 dump와 동일하다.
		if ((token = strtok(NULL, " \t")))
		{
			strcpy(testarr, input);
			token = strtok(testarr, " \t");
			temp = NULL; // temp의 경우 첫번째 ','의 주소값을 저장한다.

			for (i = 1; *(token + strlen(token) +i) != '\0'; ++i)
				if (*(token + strlen(token)+i) == ',')
				{
					*(token+strlen(token)+i) = ' ';
					temp = token+strlen(token)+i;
					break;
				}

			if (!(token = strtok(NULL, " \t")))
				return -1;
			if (temp == NULL || temp < token)
				return -1;

			for (i = 0; (token[i] >= '0' && token[i] <= '9') || (token[i] >= 'A' && token[i] <= 'F') || (token[i] >= 'a' && token[i] <= 'f'); ++i);

			if (token[i] == '\0')
			{
				if (strlen(token) > 7)
					return -1;

				*start = 0;
				k = 1;
				for (i-=1; i >=0; --i)
				{
					if (token[i] >= '0' && token[i] <= '9')
						*start += k * (token[i] - '0');
					else if(token[i] >= 'a' && token[i] <= 'z')
						*start += k * (token[i] - 'a' + 10);
					else
						*start += k * (token[i] - 'A' + 10);
					k *= 16;
				}
				
				if (*start >= 1048576)
					return -1;

				temp1 = NULL; // temp1의 경우 두번째 ','의 주소값을 저장한다.
				for (i = 1; *(token + strlen(token) + i) != '\0'; ++i)
					if (*(token + strlen(token)+i) == ',')
					{
						*(token+strlen(token)+i) = ' ';
						temp1 = token + strlen(token)+i;
						break;
					}
				
				if ((token = strtok(NULL, " \t")))
				{
					if (temp1 == NULL || temp1 < token || temp > token)
						return -1;
					for (i = 0; (token[i] >= '0' && token[i] <= '9') || (token[i] >= 'A' && token[i] <= 'F') || (token[i] >= 'a' && token[i] <= 'f'); ++i);

					if (token[i] == '\0')
					{
						if (strlen(token) > 7)
							return -1;
						*end = 0;
						k = 1;
						for (i -= 1; i >=0; --i)
						{
							if (token[i] >= '0' && token[i] <= '9')
								*end += k * (token[i] - '0');
							else if(token[i] >= 'a' && token[i] <= 'z')
								*end += k * (token[i] - 'a' + 10);
							else
								*end += k * (token[i] - 'A' + 10);
							k *= 16;
						}
						
						if (*end >= 1048576 || *start > *end)
							return -1;

						if ((token = strtok(NULL, " \t")))
						{
							if (temp1 > token)
								return -1;
							for (i = 0; (token[i] >= '0' && token[i] <= '9') || (token[i] >= 'A' && token[i] <= 'F') || (token[i] >= 'a' && token[i] <= 'f'); ++i);

							if (token[i] == '\0')
							{	
								if (strlen(token) > 2)
									return -1;
								*value = 0;
								k = 1;
								for (i -= 1; i >= 0; --i)
								{
									if (token[i] >= '0' && token[i] <= '9')
										*value += k * (token[i] - '0');
									else if(token[i] >= 'a' && token[i] <= 'z')
										*value += k * (token[i] - 'a' + 10);
									else
										*value += k * (token[i] - 'A' + 10);
									k *= 16;
								}

								if ((token = strtok(NULL, " \t")))
									return -1;
								which = FILL;
							}
						}
					}
				}
			}
		}
	}
	else if (strcmp(token, "reset") == 0) // 사용자가 reset값을 올바르게 호출시 which에 RESET을 저장한다.
	{
		if (!(token = strtok(NULL, " \t")))
			which = RESET;
	}
	else if (strcmp(token, "opcodelist") == 0) // 사용자가 opcodelist을 올바르게 호출 시 which에 OPLIST를 저장한다.
	{
		if (!(token = strtok(NULL, " \t")))
			which = OPLIST;
	}
	else if (strcmp(token, "opcode") == 0) // 사용자가 opcode mnemonic을 올바르게 호출시 which에 OPMNEMONIC을 저장하고 start에 사용자가 입력한 문자열에서 mnemonic이 나오는 시작 주소값을 value에 입력한 mnemonic의 길이를 저장한다.
	{
		if ((token = strtok(NULL, " \t"))) // opcode 뒤에 사용자가 입력한 문자열이 있는지 확인
		{
			if (strlen(token) > 6) // 입력한 mnemonic이 6자보다 큰값인 경우 -1을 반환한다.
				return -1;
			// 문자열에서 mnemonic의 위치를 찾는다.
			for (i = 0; i < strlen(input); ++i)
			{
				j = 0;
				if (input[i] == token[j])
				{
					for (k = 0; k < strlen(token); ++k)
						if (input[i+k] != token[j+k])
							break;
					if (k == strlen(token))
					{
						*start = i;
						*value = strlen(token);
						break;
					}
				}
			}
			if (!(token = strtok(NULL, " \t")))
				which = OPMNEMONIC;
		}
	}
	else if (strcmp(token, "type") == 0)
	{
		if (!(token = strtok(NULL, " \t")))
			return -1;
		if (strlen(token) > 99)
			return -1;

		i = 0;
		while (input[i] != '\0')
		{
			j = 0;
			if (input[i] == token[j])
			{
				for (k = 0; k < strlen(token); ++k)
					if (input[i+k] != token[j+k])
						break;
				if (k == strlen(token))
				{
					*start = i;
					*value = strlen(token);
					break;
				}
			}
			++i;
		}

		if (!(token = strtok(NULL, " \t")))
			which = TYPE;
	}
	else if (strcmp(token, "assemble") == 0) // start -> index of assemble file, value -> length of file name
	{
		if (!(token = strtok(NULL, " \t")))
			return -1;
		if (strlen(token) > 99)
			return -1;

		for (i = 0; token[i] != '.'; ++i)
			if (token[i] == '\0')
				return -1;

		if (strlen(token) != i + 4 || i == 0)
			return -1;
		if (token[i+1] != 'a' && token[i+2] != 's' && token[i+3] != 'm')
			return -1;
		
		i = 0;
		while (input[i] != '\0')
		{
			j = 0;
			if (input[i] == token[j])
			{
				for (k = 0; k < strlen(token); ++k)
					if (input[i+k] != token[j+k])
						break;
				if (k == strlen(token))
				{
					*start = i;
					*value = strlen(token);
					break;
				}
			}
			++i;
		}

		if (!(token = strtok(NULL, " \t")))
			which = ASSEMBLE;
	}
	else if (strcmp(token, "symbol") == 0)
	{
		if (!(token = strtok(NULL, " \t")))
			which = SYMBOL;
	}
	else if (strcmp(token, "progaddr") == 0 )
	{
		*value = 0;
		if ((token = strtok(NULL, " \t")))
		{
			j = 1;
			for (i = strlen(token)-1; i >= 0; --i)
			{
				if (token[i] >= '0' && token[i] <= '9')
					*value += (token[i] - '0') * j;
				else if (token[i] >= 'A' && token[i] <= 'F')
					*value += (token[i] -'A'+10) * j;
				else if (token[i] >= 'a' && token[i] <= 'f')
					*value += (token[i] -'a'+10) * j;
				else
					return -1;

				j *= 16;
			}

			if (*value > 0xFFFFFF || *value < 0)
				return -1;

			if (!(token = strtok(NULL, " \t")))
				which = PROGADDR;
		}
	}
	else if (strcmp(token, "loader") == 0) // start == 첫번째 file의 index, end == 두번째 file의 index, value == 세번째 파일의 index
	{
		*start = -1; *end = -1; *value = -1;
		// 첫번째 object file의 이름이 없을 시 -1 반환
		if (!(token = strtok(NULL, " \t")))
				return -1;
		// 첫번째 object file의 이름이 obj파일이 아닐시 -1 반환
		for (i = 0; token[i]; ++i)
			if (token[i] == '.')
				break;
		if (strlen(&token[i]) != 4 || i == 0)
			return -1;
		if (token[i+1] != 'o' || token[i+2] != 'b' || token[i+3] != 'j')
			return -1;
		for (i = 0; input[i]; ++i) // store index of first object file name in input string in 'start'
		{
			j = i;
			for (k = 0; k < strlen(token); ++j, ++k)
				if (input[j] != token[k])
					break;
			if (k == strlen(token))
			{
				*start = i;
				break;
			}
		}

		which = LOADER;
		if (!(token = strtok(NULL, " \t")))
			return which;

		for (i = 0; token[i]; ++i)
			if (token[i] == '.')
				break;
		if (strlen(&token[i]) != 4 || i == 0)
			return -1;
		if (token[i+1] != 'o' || token[i+2] != 'b' || token[i+3] != 'j')
			return -1;
		for (i = 0; input[i]; ++i) // store index of first object file name in input string in 'start'
		{
			j = i;
			for (k = 0; k < strlen(token); ++j, ++k)
				if (input[j] != token[k])
					break;
			if (k == strlen(token))
			{
				*end = i;
				break;
			}
		}
		
		if (!(token = strtok(NULL, " \t")))
			return which;

		for (i = 0; token[i]; ++i)
			if (token[i] == '.')
				break;
		if (strlen(&token[i]) != 4 || i == 0)
			return -1;
		if (token[i+1] != 'o' || token[i+2] != 'b' || token[i+3] != 'j')
			return -1;
		for (i = 0; input[i]; ++i) // store index of first object file name in input string in 'start'
		{
			j = i;
			for (k = 0; k < strlen(token); ++j, ++k)
				if (input[j] != token[k])
					break;
			if (k == strlen(token))
			{
				*value = i;
				break;
			}
		}

		if ((token = strtok(NULL, " \t")))
			return -1;
	}
	else if (strcmp(token, "run") == 0)
	{
		if (!(token = strtok(NULL, " \t")))
			which = RUN;
	}
	else if (strcmp(token, "bp") == 0)
	{
		which = BP;
		*value = -1;
		*start = 0;
		if (!(token = strtok(NULL, " \t")))
			return which;

		if (strcmp(token, "clear") == 0)
		{
			if ((token = strtok(NULL, " \t")))
				return -1;
			else
			{
				*start = 1;
				return which;
			}
		}

		*value = 0;
		j = 1;
		for (i = strlen(token)-1; i >= 0; --i)
		{
			if (token[i] >= '0' && token[i] <= '9')
				*value += (token[i] - '0' ) * j;
			else if (token[i] >= 'a' && token[i] <= 'f')
				*value += (token[i] - 'a') * j;
			else if (token[i] >= 'A' && token[i] <= 'F')
				*value += (token[i] - 'A') * j;
			else
				return -1;

			j *= 16;
		}

		if (*value > 0xFFFFFF || *value < 0)
			return -1;
		if ((token = strtok(NULL, " \t")))
			return -1;
	}

	return which;
}
int HashFunction(char* key) // key를 받아 해당하는 해시값을 반환한다.
{
	int hash = 0;
	int i = 0;
	int len = strlen(key);

	for(i = 0; i < len; ++i)
	{
		if (hash*31 + key[i] < 0)
			hash %= hash;
		hash = hash*31 + key[i];
	}

	return hash % 20;
}
void DeleteLinkedList(Node** head) // 링크드리스트의 head의 주소값을 받아 해당 리스트의 동적할당을 해제한다.
{
	Node* tempnode = *head;
	Node* nextnode;

	while (tempnode)
	{
		nextnode = tempnode->nextnode;
		free(tempnode->val);
		free(tempnode);
		tempnode = nextnode;
	}

	*head = NULL;
}
void InsertHistoryList(LinkedList* hlist, char* data) // HistoryList와 사용자의 입력 문자열을 받아 새로이 저장한다.
{
	Node* tempnode = MakeNode((void*)data, (int)strlen(data)+1);

	if (hlist->count == 0)
	{
		hlist->head = tempnode;
		hlist->tail = tempnode;
	}
	else
	{
		hlist->tail->nextnode = tempnode;
		hlist->tail = tempnode;
	}
	hlist->count += 1;
}
// 해당 문자열이 direcive일 경우 각각의 경우에 맞는 enum값을 아닐 경우 -1을 return
int FindDirective(char* arr) 
{
	if (strcmp(arr, "START") == 0)
		return START;
	else if (strcmp(arr, "END") == 0)
		return END;
	else if (strcmp(arr, "BYTE") == 0)
		return BYTE;
	else if (strcmp(arr, "WORD") == 0)
		return WORD;
	else if (strcmp(arr, "RESB") == 0)
		return RESB;
	else if (strcmp(arr, "RESW") == 0)
		return RESW;
	else if (strcmp(arr, "BASE") == 0)
		return BASE;

	return 0;
}
// 해당 문자열의 이름을 가진 instruction이 있는지 opcode table에서 찾은후 있으면 해당 주소값을 없으면 NULL값을 return
Node* FindOphash(char *input, Node* ophash[])
{
	Node* tempnode;
	char *arr;
	int num;

	if (input[0] == '+')
		 arr = input+1;
	else
		arr = input;

	num = HashFunction(arr);

	for (tempnode = ophash[num]; tempnode; tempnode = tempnode->nextnode)
		if (strcmp(arr, ((Opcode*)(tempnode->val))-> name) == 0)
			break;
	if (tempnode == NULL)
		return tempnode;

	if ((((Opcode*)(tempnode->val))->form)[0] != '3' && input[0] == '+')
		return NULL;

	return tempnode;
}
// 해당 문자열이 10진수 혹은 16진수 혹은 character 형이 맞는지 확인하고 맞을 경우 해당 값을 저장하기 위해 몇 byte가 필요한지 return. 올바른 형식이 아닐 경우 -1을 return
// ex) 16진수 : X'1F' / 10진수 : 123 / character : C'HELLO'
int CheckConstant(char* input)
{
	int i = 0;

	if (input[0] == 'X')
	{
		if (input[1] != '\'' || input[strlen(input)-1] != '\'' || strlen(input) < 4)
			return -1;

		for (i = 2; i <= strlen(input)-2; ++i)
		{
			if ((input[i] > '9' || input[0] < '0') && (input[i] < 'A' || input[i] > 'F'))
				return -1;
		}

		return (i-2)/2;
	}
	else if (input[0] == 'C')
	{
		if (input[1] != '\'' || input[strlen(input)-1] != '\'' || strlen(input) < 4)
			return -1;
		
		return strlen(input) - 3;
	}
	else if (input[0] >= '0' && input[0] <= '9')
	{
		for (i = strlen(input)-1; i >= 0; --i)
			if (input[i] > '9' || input[i] < '0')
				return -1;

		return 1;
	}
	else
		return -1;
}
// 오브젝트 코드를 읽어 external symbol table을 만든다.
int LinkPass1(char* filename, LinkedList* extsymtable, int progaddr)
{
	FILE* file;
	ExtSymbol *tempext;
	char filearr[100];
	int i, j, k;
	int conseclength = 0;
	int tempnum;
	Node* tempnode;
	
	// object file을 연다.
	file = fopen(filename, "r");
	if (file == NULL)
	{
		printf("error! There isn't %s file.\n", filename);
		return -1;
	}
	while (feof(file) == 0) // 파일을 다 읽을 때 까지 반복
	{
		fgets(filearr, 100, file);

		if (filearr[0] == 'H') // Head record의 경우
		{
			// save control section node in extern table.
			j = 0; i = 1;
			tempext = (ExtSymbol*)malloc(sizeof(ExtSymbol));
			for (k = i; filearr[k] != ' ' && k < i+6; ++k)
				tempext->name[j++] = filearr[k];
			tempext->name[j] = '\0';
			tempext->address = progaddr;
			// control section의 길이를 정수값으로 바꾸어 저장
			i += 12;
			tempnum = 0;
			for (k = i; k < i+6; ++k)
			{
				if (filearr[k] >= '0' && filearr[k] <= '9')
					tempnum = tempnum * 16 + filearr[k] - '0';
				else if (filearr[k] >= 'A' && filearr[k] <= 'F')
					tempnum = tempnum * 16 + filearr[k] - 'A' + 10;
				else
				{
					puts("error! object file format problem.");
					return -1;
				}
			}
			conseclength = tempnum;
			tempext->length = conseclength;
			// 노드의 데이터 부분을 모두 만들었으니 이를 노드에 대입
			tempnode = (Node*)malloc(sizeof(Node));
			tempnode->val = (void*)tempext;
			tempnode->nextnode = NULL;
			// 노드를 External symbol table에 저장
			if (extsymtable->count == 0)
				extsymtable->head = tempnode;
			else
			{
				if (GetExtaddr(tempext->name, extsymtable) > 0)
				{
					puts("There is duplicated external symbol name!");
					return -1;
				}
				extsymtable->tail->nextnode = tempnode;
			}
			extsymtable->tail = tempnode;
			extsymtable->count += 1;
		}
		else if (filearr[0] == 'D') // Define record case
		{
			i = 1;
			while (filearr[i] != '\n' && filearr[i] != '\0')
			{
				// Symbol의 이름을 읽는다.
				tempext = (ExtSymbol*)malloc(sizeof(ExtSymbol));
				j = 0;
				for (k = i; filearr[k] != ' ' && k < i+6; ++k)
					tempext->name[j++] = filearr[k];
				tempext->name[j] = '\0';
				i += 6;
				// Symbol의 상대 주소값을 저장한다.
				tempnum = 0;
				for (k = i; k < i+6; ++k)
				{
					if (filearr[k] >= '0' && filearr[k] <= '9')
						tempnum = tempnum*16 + filearr[k] - '0';
					else if (filearr[k] >= 'A' && filearr[k] <= 'F')
						tempnum = tempnum*16 + filearr[k] -'A'+10;
					else
					{
						puts("error! object file format problem");
						return -1;
					}
				}
				// 상대 주소값 + 프로그램 상대 주소값이 메모리의 범위를 벗어나면 에러를 출력한다.
				if (progaddr + tempnum > 0xFFFFFF)
				{
					puts("error! memory is overflow.");
					return -1;
				}
				// External symbol 구조체에 값을 저장한다.
				tempext->address = progaddr + tempnum;
				tempext->length = -1;
				tempnode = (Node*)malloc(sizeof(Node));
				tempnode->val = (void*)tempext;
				tempnode->nextnode = NULL;
				// External symbol table에 노드를 추가한다.
				if (extsymtable->count == 0)
					extsymtable->head = tempnode;
				else
				{
					if (GetExtaddr(tempext->name, extsymtable) > 0)
					{
						puts("error! There is duplicated external symbol name.");
						return -1;
					} 
					extsymtable->tail->nextnode = tempnode;
				}
				extsymtable->count += 1;
				extsymtable->tail = tempnode;
				
				i += 6;
			}
		}
		else if (filearr[0] == 'E') // End record case
		{
			// End record 밑에 추가적인 control section이 있을 경우를 위해 control section의 시작 주소값을 바꾼다.
			progaddr += conseclength;
			conseclength = 0;
		}
	}
	fclose(file);	
	return progaddr;
}
// External Symbol table에서 이름을 통해 symbol 값을 찾은 다음 해당 symbol의 address를 반환한다.
int GetExtaddr(char* name, LinkedList* extsym)
{
	Node* tempnode;
	if (extsym->head == NULL)
	{
		puts("error! externsymbol table is empty.");
		return -1;
	}

	tempnode = extsym->head;

	for (int i = 0; i < extsym->count; ++i)
	{
		if (strcmp(name, ((ExtSymbol*)(tempnode->val))->name) == 0)
			return ((ExtSymbol*)(tempnode->val))->address;
		tempnode = tempnode->nextnode;
	}
	
	return 0;
}
// pass1 때 만든 External Symbol table을 통해  load를 한다.
int LinkPass2(char* filename, LinkedList* extsym, unsigned char *memory)
{
	FILE* file;
	char rarr[40][20]; // reference number, reference name을 저장하는 배열이다.
	char filearr[100]; // file stream을 통해 읽은 문자열을 저장하는 배열
	char temparr[100]; // 문자열을 임시적으로 저장하는 배열
	int i, j, k; // 임시적인 정수를 저장하는 변수
	int progaddr = 0; // 프로그램을 loading할 시작 주소값을 저장하는 	변수
	int tempnum = 0; // 임시적인 정수를 저장하는 변수
	int offset = 0; // 
	int conseclength; // control section의 길이를 저장하는 변수
	int excuteaddr = -2; // end record에 쓰여있는 실행주소를 저장하는 변수
	
	file = fopen(filename, "r");

	if (file == NULL)
	{
		printf("error! There isn't %s file.\n", filename);
		return -1;
	}
	
	while (feof(file) == 0)
	{
		fgets(filearr, 100, file);

		if (filearr[0] == 'H')
		{
			// get addresss in which program stores value
			i = 1; j = 0;
			for (k = i; filearr[k] != ' ' && k < i+6; ++k)
				temparr[j++] = filearr[k];
			temparr[j] = '\0';
			progaddr = GetExtaddr(temparr, extsym);
			strcpy(rarr[1], temparr);
			// 해당 control section의 길이를 저장
			i += 12;
			conseclength = HexcharToInt(&filearr[i], 6);
			if (conseclength == -1)
				return -1;
		}
		else if (filearr[0] == 'R')
		{
			//rarr에 reference number와 reference name을 저장한다.
			i = 1;
			while (i < strlen(filearr)-1)
			{
				tempnum = 0;
				for (k = i; k < i+2; ++k)
				{
					if (filearr[k] >= '0' && filearr[k] <= '9')
						tempnum = tempnum*16 + filearr[k] - '0';
					else if (filearr[k] >= 'A' && filearr[k] <= 'F')
						tempnum = tempnum*16 + filearr[k] - 'A' + 10;
					else
					{
						puts("error! object file format problem.");
						return -1;
					}
				}

				j = 0;
				for (k = i+2; k < i+8 && filearr[k] != ' ' && filearr[k] != '\n' && filearr[k] != '\0'; ++k)
					rarr[tempnum][j++] = filearr[k];
				rarr[tempnum][j] = '\0';
				
				i += 8;
			}
		}
		else if (filearr[0] == 'T') // Text record
		{
			i = 1;
			offset = HexcharToInt(&filearr[i], 6); // 프로그램을 로드하기 시작하는 주소로부터 상대적인 값이다.
			if (offset == -1)
				return -1;
			i += 6;
			j = HexcharToInt(&filearr[i], 2); // Text record의 길이
			if (j == -1)
				return -1;
			// 메모리에 로드를 한다.
			i += 2;
			for (k = 0; k < j*2; k+=2)
			{
				tempnum = HexcharToInt(&filearr[i+k], 2);
				if (tempnum == -1)
					return -1;
				if (progaddr+offset+(k/2) > 0xFFFFFF)
				{
					puts("error! memory overflow.");
					return -1;
				}
				memory[progaddr+offset+(k/2)] = (unsigned char)tempnum;
			}
		}
		else if (filearr[0] == 'M') // modify record
		{
			//modify할 주소값을 정수로 저장
			i = 1;
			offset = HexcharToInt(&filearr[i], 6);
			if (offset == -1)
				return -1;
			i += 6;
			k = HexcharToInt(&filearr[i], 2); //k = length of memory that will be modified
			if (k == -1)
				return -1;
			if (progaddr + ((k+1)/2) > 0xFFFFFF)
			{
				puts("error! memory overflow.");
				return -1;
			}
			// load value to modify
			tempnum = 0;
			if (k%2)
			{
				for (j = 0; j < k/2; ++j)
					tempnum = (tempnum << 8) + memory[progaddr+offset+j+1];
				tempnum = tempnum | ((memory[progaddr+offset] & 0xF) << (k*4));
			}
			else
				for (j = 0; j < k/2; ++j)
					tempnum = (tempnum << 8) + memory[progaddr+offset+j];
			
			// tempnum sign extention
			if (tempnum & (1 << (k*4-1)))
				tempnum = tempnum | (0xFFFFFFFF << (k*4)) ;
			i+=2;
			j = HexcharToInt(&filearr[i+1], 2);
			if (j == -1)
				return -1;
			j = GetExtaddr(rarr[j], extsym);
			// 값을 더해주거나 빼준다.
			if (filearr[i] == '+')
				tempnum += j;
			else
				tempnum -= j;
			// store value in memory space
			if (k%2)
			{
				for (j = 0; j < k/2; ++j)
					memory[progaddr+offset+j+1] = (unsigned char)(tempnum >> (8*(k/2 - 1 - j)));
				memory[progaddr+offset] = (memory[progaddr+offset] & 0xF0) | (unsigned char)((tempnum >> ((k-1)*4)) & 0xF);
			}
			else
				for (j = 0; j < k/2; ++j)
					memory[progaddr+offset+j] = (unsigned char)(tempnum >> (8*(k/2 - 1 - j)));
		}
		else if (filearr[0] == 'E') // End record
		{
			progaddr += conseclength;

			if (excuteaddr == -2 && filearr[1] != '\0')
				excuteaddr = HexcharToInt(&filearr[1], 6);
			if (excuteaddr == -1)
				return -1;
		}
	}

	return excuteaddr;
}
// 문자열로 저장되어 있는 16진수를 정수값으로 변환후 반환
int HexcharToInt(char *arr, int num)
{
	int result = 0;
	
	for (int i = 0; i < num; ++i)
	{
		if (arr[i] >= '0' && arr[i] <= '9')
			result = result*16 + arr[i]-'0';
		else if (arr[i] >= 'A' && arr[i] <= 'F')
			result = result*16 + arr[i]-'A'+10;
		else
		{
			puts("error! There is not Hexa Character.");
			return -1;
		}
	}

	return result;
}
// 프로그램을 실행한다.
int RunProgram(unsigned char* memory, int progaddr, LinkedList *bplist, int* reg, int lastpc)
{
	unsigned char opcode;
	int ni, xbpe;
	int tempnum;
	int disp;
	int i;
	char temparr[100];
	Node* tempnode;
	
	reg[PCREG] = progaddr; // PC 레지스터에 프로그램의 시작 주소값을 입력
	reg[LREG] = lastpc + progaddr; // L register에 프로그램의 마지막 주소값을 입력
	while (reg[PCREG] < lastpc+progaddr)
	{
		
		opcode = memory[reg[PCREG]];
		ni = opcode % 4;
		opcode -= ni;
		// break point가 있을 시 정지하고 레지스터를 출력
		for (tempnode = bplist->head; tempnode; tempnode = tempnode->nextnode)
			if (reg[PCREG] == *(int*)(tempnode->val))
			{	
				printf("A : %06X X  : %06X\n", reg[AREG], reg[XREG]);
				printf("L : %06X PC : %06X\n", reg[LREG], reg[PCREG]);
				printf("B : %06X S  : %06X\n", reg[BREG], reg[SREG]);
				printf("T : %06X\n", reg[TREG]);
				printf("Stop at checkpoint[%06X]\n", reg[PCREG]);
	
				temparr[0] = '\0';
				while (strcmp("run", temparr))
				{
					fgets(temparr, 100, stdin);
					temparr[strlen(temparr)-1] = '\0';
				}
				break;
			}
		// 명령어의 형식을 분석하여 n, i, b, p, x, e 값을 저장하고 target address의 값을 저장합니다.
		switch (opcode)
		{
		// 1 format
		case 0xC4:
		case 0xC0:
		case 0xF4:
		case 0xC8:
		case 0xF0:
		case 0xF8:
			reg[PCREG]++;
			break;
		// 2 format
		case 0x90:
		case 0xB4:
		case 0xA0:
		case 0x9C:
		case 0x98:
		case 0xAC:
		case 0xA4:
		case 0xA8:
		case 0x94:
		case 0xB0:
		case 0xB8:
			disp = memory[reg[PCREG]+1];
			reg[PCREG]+=2;
			break;
		default:
			xbpe = memory[reg[PCREG]+1] >> 4;
			if (ni == 0) // SIC case
			{
				disp = HexbitToInt(&memory[reg[PCREG]+1], 15);
				if (memory[reg[PCREG]+1] & 0x80)
					disp += reg[XREG];
				reg[PCREG] += 3;
			}
			else if (xbpe &1) // format 4
			{
				disp = HexbitToInt(&memory[reg[PCREG]+1], 20);
				reg[PCREG] += 4;
				if (xbpe & 8)
					disp = (disp + reg[XREG]) & 0xFFFFFF;
			}
			else // 3 format
			{
				disp = HexbitToInt(&memory[reg[PCREG]+1], 12);
				reg[PCREG] += 3;
				
				if (xbpe & 2) // PC relative
					disp = (SignExtension(disp, 12) + SignExtension(reg[PCREG], 24)) & 0xFFFFFF;
				else if (xbpe & 4) // Base relative
					disp = (disp + reg[BREG]) & 0xFFFFFF;
				if (xbpe & 8) // X
					disp = (disp + reg[XREG]) & 0xFFFFFF;
			}
		}
		// opcode에 따른 명령을 실행
		if (opcode == 0x18) // ADD
		{
			if (ni == 1) // imediate addressing
				tempnum = disp;
			else if (ni == 2) // indirect addressing
			{
				tempnum = HexbitToInt(&memory[disp], tempnum);
				tempnum = HexbitToInt(&memory[tempnum], 24);
			}
			else // simple addressing
				tempnum = HexbitToInt(&memory[disp], 24);

			reg[AREG] = (SignExtension(reg[AREG], 24) + SignExtension(tempnum, 24)) & 0xFFFFFF;
		}
		else if (opcode == 0x90) // ADDR
		{
			reg[disp & 0xF] = (SignExtension(reg[disp >> 4], 24) + SignExtension(reg[disp & 0xF], 24)) & 0xFFFFFF;
		}
		else if (opcode == 0x40) // AND
		{
			if (ni == 1)
				reg[AREG] = reg[AREG] & disp;
			else if (ni == 2)
			{
				tempnum = HexbitToInt(&memory[disp], 24);
				reg[AREG] = reg[AREG] & HexbitToInt(&memory[tempnum], 24);
			}
			else
				reg[AREG] = reg[AREG] & HexbitToInt(&memory[disp], 24);
		}
		else if (opcode == 0xB4) // CLEAR
		{
			reg[disp >> 4] = 0;
		}
		else if (opcode == 0x28) // COMP
		{
			if (ni == 1)
				tempnum = disp;
			else if (ni == 2)
			{
				tempnum = HexbitToInt(&memory[disp], 24);
				tempnum = HexbitToInt(&memory[tempnum], 24);
			}
			else
				tempnum = HexbitToInt(&memory[disp], 24);

			if (SignExtension(reg[AREG], 24) > SignExtension(tempnum, 24))
				reg[SWREG] = 2;
			else if (SignExtension(reg[AREG], 24) < SignExtension(tempnum, 24))
				reg[SWREG] = 1;
			else
				reg[SWREG] = 0;
		}
		else if (opcode == 0xA0) // COMPR
		{
			if (SignExtension(reg[disp >> 4], 24) > SignExtension(reg[disp & 0xF], 24))
				reg[SWREG] = 2;
			else if (SignExtension(reg[disp >> 4], 24) < SignExtension(reg[disp & 0xF], 24))
				reg[SWREG] = 1;
			else
				reg[SWREG] = 0;
		}
		else if (opcode == 0x24) // DIV
		{
			if (ni == 1)
				tempnum = disp;
			else if (ni == 2)
			{
				tempnum = HexbitToInt(&memory[disp], 24);
				tempnum = HexbitToInt(&memory[tempnum], 24);
			}
			else
				tempnum = HexbitToInt(&memory[disp], 24);

			reg[AREG] = (SignExtension(reg[AREG], 24) / SignExtension(tempnum, 24) ) & 0xFFFFFF;
		}
		else if (opcode == 0x9C) // DIVR
		{
			reg[disp & 0xF] = (SignExtension(reg[disp & 0xF], 24) / SignExtension(reg[disp >> 4], 24)) & 0xFFFFFF;
		}
		else if (opcode == 0x3C) // J
		{
			if (ni == 2)
				disp = HexbitToInt(&memory[disp], 24);

			reg[PCREG] = disp;
		}
		else if (opcode == 0x30) // JEQ
		{
			if (reg[SWREG] == 0)
			{
				if (ni == 2)
					disp = HexbitToInt(&memory[disp], 24);
				reg[PCREG] = disp;
			}
		}
		else if (opcode == 0x34) // JGT
		{
			if (reg[SWREG] == 2)
			{
				if (ni == 2)
					disp = HexbitToInt(&memory[disp], 24);
				reg[PCREG] = disp;
			}
		}
		else if (opcode == 0x38) // JLT
		{
			if (reg[SWREG] == 1)
			{
				if (ni == 2)
					disp = HexbitToInt(&memory[disp], 24);
				reg[PCREG] = disp;
			}
		}
		else if (opcode == 0x48) // JSUB
		{
			reg[LREG] = reg[PCREG];
			reg[PCREG] = disp;
		}
		else if (opcode == 0x00) // LDA
		{
			if (ni == 1)
				tempnum = disp;
			else if (ni == 2)
			{
				tempnum = HexbitToInt(&memory[disp], 24);
				tempnum = HexbitToInt(&memory[tempnum], 24);
			}
			else
				tempnum = HexbitToInt(&memory[disp], 24);

			reg[AREG] = tempnum;
		}
		else if (opcode == 0x68) // LDB
		{
			if (ni == 1)
				tempnum = disp;
			else if (ni == 2)
			{
				tempnum = HexbitToInt(&memory[disp], 24);
				tempnum = HexbitToInt(&memory[tempnum], 24);
			}
			else
				tempnum = HexbitToInt(&memory[disp], 24);

			reg[BREG] = tempnum;
		}
		else if (opcode == 0x50) // LDCH
		{
			if (ni == 1)
				tempnum = disp;
			else if (ni == 2)
			{
				tempnum = HexbitToInt(&memory[disp], 24);
				tempnum = HexbitToInt(&memory[tempnum], 8);
			}
			else
				tempnum = HexbitToInt(&memory[disp], 8);

			reg[AREG] = tempnum & 0xFF;
		}
		else if (opcode == 0x08) // LDL
		{
			if (ni == 1)
				tempnum = disp;
			else if (ni == 2)
			{
				tempnum = HexbitToInt(&memory[disp], 24);
				tempnum = HexbitToInt(&memory[tempnum], 24);
			}
			else
				tempnum = HexbitToInt(&memory[disp], 24);

			reg[LREG] = tempnum;
		}
		else if (opcode == 0x6C) // LDS
		{
			if (ni == 1)
				tempnum = disp;
			else if (ni == 2)
			{
				tempnum = HexbitToInt(&memory[disp], 24);
				tempnum = HexbitToInt(&memory[tempnum], 24);
			}
			else
				tempnum = HexbitToInt(&memory[disp], 24);

			reg[SREG] = tempnum;
		}
		else if (opcode == 0x74) // LDT
		{
			if (ni == 1)
				tempnum = disp;
			else if (ni == 2)
			{
				tempnum = HexbitToInt(&memory[disp], 24);
				tempnum = HexbitToInt(&memory[tempnum], 24);
			}
			else
				tempnum = HexbitToInt(&memory[disp], 24);

			reg[TREG] = tempnum;
		}
		else if (opcode == 0x04) // LDX
		{
			if (ni == 1)
				tempnum = disp;
			else if (ni == 2)
			{
				tempnum = HexbitToInt(&memory[disp], 24);
				tempnum = HexbitToInt(&memory[tempnum], 24);
			}
			else
				tempnum = HexbitToInt(&memory[disp], 24);

			reg[XREG] = tempnum;
		}
		else if (opcode == 0x20) // MUL
		{
			if (ni == 0)
				tempnum = disp;
			else if (ni == 1)
			{
				tempnum = HexbitToInt(&memory[disp], 24);
				tempnum = HexbitToInt(&memory[tempnum], 24);
			}
			else
				tempnum = HexbitToInt(&memory[disp], 24);

			reg[AREG] = (SignExtension(reg[AREG], 24) * SignExtension(tempnum, 24)) & 0xFFFFFF;
		}
		else if (opcode == 0x60) // MULR
		{
			reg[disp & 0xF] = (SignExtension(reg[disp & 0xF], 24) * SignExtension(reg[disp >> 4], 24)) & 0xFFFFFF;
		}
		else if (opcode == 0x44) // OR
		{
			if (ni == 1)
				tempnum = disp;
			else if (ni == 2)
			{
				tempnum = HexbitToInt(&memory[disp], 24);
				tempnum = HexbitToInt(&memory[tempnum], 24);
			}
			else
				tempnum = HexbitToInt(&memory[disp], 24);

			reg[AREG] = reg[AREG] | tempnum;
		}
		else if (opcode == 0xAC) // RMO
		{
			reg[disp & 0xF] = reg[disp >> 4];
		}
		else if (opcode == 0x4C) // RSUB
		{
			reg[PCREG] = reg[LREG];
		}
		else if (opcode == 0xA4) // SHIFTL
		{
			reg[disp >> 4] = (reg[disp >> 4] << (disp & (0xF))) & 0xFFFFFF;
		}
		else if (opcode == 0xA8) // SHIFTR
		{
			reg[disp >> 4] = reg[disp >> 4] >> (disp & (0xF));
		}
		else if (opcode == 0x0C) // STA
		{
			if (ni == 2)
				disp = HexbitToInt(&memory[disp], 24);

			for (i = 0; i < 3; ++i)
				memory[disp+i] = (reg[AREG] >> (16 - 8*i)) & 0xFF;
		}
		else if (opcode == 0x78) // STB
		{
			if (ni == 2)
				disp = HexbitToInt(&memory[disp], 24);

			for (i = 0; i < 3; ++i)
				memory[disp+i] = (reg[BREG] >> (16 - 8*i)) & 0xFF;
		}
		else if (opcode == 0x54) // STCH
		{
			if (ni == 2)
				disp = HexbitToInt(&memory[disp], 24);
			memory[disp] = reg[AREG] & 0xFF;
		}
		else if (opcode == 0x14) // STL
		{
			if (ni == 2)
				disp = HexbitToInt(&memory[disp], 24);

			for (i = 0; i < 3; ++i)
				memory[disp+i] = (reg[LREG] >> (16 - 8*i)) & 0xFF;
		}
		else if (opcode == 0x7C) // STS
		{
			if (ni == 2)
				disp = HexbitToInt(&memory[disp], 24);

			for (i = 0; i < 3; ++i)
				memory[disp+i] = (reg[SREG] >> (16 - 8*i)) & 0xFF;
		}
		else if (opcode == 0xE8) // STSW
		{
			if (ni == 2)
				disp = HexbitToInt(&memory[disp], 24);

			for (i = 0; i < 3; ++i)
				memory[disp+i] = (reg[SWREG] >> (16 - 8*i)) & 0xFF;
		}
		else if (opcode == 0x84) // STT
		{
			if (ni == 2)
				disp = HexbitToInt(&memory[disp], 24);

			for (i = 0; i < 3; ++i)
				memory[disp+i] = (reg[TREG] >> (16 - 8*i)) & 0xFF;
		}
		else if (opcode == 0x10) // STX
		{
			if (ni == 2)
				disp = HexbitToInt(&memory[disp], 24);

			for (i = 0; i < 3; ++i)
				memory[disp+i] = (reg[XREG] >> (16 - 8*i)) & 0xFF;
		}
		else if (opcode == 0x1C) // SUB
		{
			if (ni == 1)
				tempnum = disp;
			else if (ni == 2)
			{
				tempnum = HexbitToInt(&memory[disp], 24);
				tempnum = HexbitToInt(&memory[tempnum], 24);
			}
			else
				tempnum = HexbitToInt(&memory[disp], 24);

			reg[AREG] = (SignExtension(reg[AREG], 24) - SignExtension(tempnum, 24)) & 0xFFFFFF;
		}
		else if (opcode == 0x94) // SUBR
		{
			reg[disp & 0xFF] = (SignExtension(reg[disp & 0xFF], 24) - SignExtension(reg[disp >> 4], 24)) & 0xFFFFFF;
		}
		else if (opcode == 0xE0) // TD
		{
			reg[SWREG] = 1;
		}
		else if (opcode == 0xF8) // TIO
		{
			reg[SWREG] = 1;
		}
		else if (opcode == 0x2C) // TIX
		{
			if (ni == 1)
				tempnum = disp;
			else if (ni == 2)
			{
				tempnum = HexbitToInt(&memory[disp], 24);
				tempnum = HexbitToInt(&memory[tempnum], 24);
			}
			else
				tempnum = HexbitToInt(&memory[disp], 24);

			reg[XREG] = (SignExtension(reg[XREG], 24) + 1) & 0xFFFFFF;

			if (SignExtension(reg[XREG] , 24) < SignExtension(tempnum, 24))
				reg[SWREG] = 1;
			else if (SignExtension(reg[XREG] , 24) == SignExtension(tempnum, 24))
				reg[SWREG] = 0;
			else
				reg[SWREG] = 2;
		}
		else if (opcode == 0xB8) // TIXR
		{
			reg[XREG] = (SignExtension(reg[XREG], 24) + 1) & 0xFFFFFF;
			
			if (SignExtension(reg[XREG] , 24) < SignExtension(reg[disp >> 4], 24))
				reg[SWREG] = 1;
			else if (SignExtension(reg[XREG] , 24) == SignExtension(reg[disp >> 4], 24))
				reg[SWREG] = 0;
			else
				reg[SWREG] = 2;
		}
	}
	// 프로그램이 끝나면 레지스터를 출력
	printf("A : %06X X  : %06X\n", reg[AREG], reg[XREG]);
	printf("L : %06X PC : %06X\n", reg[LREG], reg[PCREG]);
	printf("B : %06X S  : %06X\n", reg[BREG], reg[SREG]);
	printf("T : %06X\n", reg[TREG]);
	puts("End Program");

	return 1;
}
// memory에 저장되어 있는 값을 bit단위로 읽어 이를 정수로 변환후 반환하는 함수
int HexbitToInt(unsigned char* arr, int num)
{
	int result = 0;
	int i;
	
	if (num % 8)
	{
		result = arr[0] & ((1 << (num%8)) - 1);
		arr += 1;
	}
	for (i = 0; i < num/8; ++i)
		result = (result << 8) + arr[i];

	return result;
}
int SignExtension(int num, int bit)
{
	if (num & (1 << (bit-1)))
		return num | (0xFFFFFFFF << bit);
	return num;
}
