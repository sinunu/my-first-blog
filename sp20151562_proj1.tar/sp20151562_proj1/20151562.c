#include "20151562.h"

int main()
{
	char userinput[100]; // 사용자가 입력한 문자열을 저장하는 변수
	char temparr[100]; // 임시적으로 배열을 받아 사용할 때 사용하는 변수
	Node* tempnode = NULL; // 임시적으로 Node를 받을 때 사용하는 변수
	HistoryList hlist = {0, NULL, NULL}; // 사용자가 입력했던 문자열을 history 메뉴를 선택했을 시 보여주기위해 링크드 리스트를 통해 저장 및 관리하는 구조체
	int i, j, k; // 임시적인 변수
	DIR *dp; // 디렉토리를 열기위한 변수
	struct dirent *dent; // 디렉토리 정보를 저장하기 위한 변수
	struct stat sbuf; // 파일의 정보를 저장하기 위한 변수
	char memory[1048576]; // 메모리 공간
	int start, end, value; // dump, edit, fill 명령을 했을시 주소값과 저장할 값을 저장하는 변수
	int dumpadd = -1; // dump가 어디까지 출력했는지 저장하는 변수
	int which; // 어떤 명령을 선택했는지 저장하는 변수.
	Node* ophash[20]; // opcodelist를 저장하는 hashtable
	FILE *file; // opcode.txt를 열기위한 변수
	Opcode *optemp = NULL; // Opcode 구조체를 저장하기 위한 임시변수

	for (i = 0; i < 20; ++i) // 해쉬테이블의 배열을 모두 NULL값으로 초기화
		ophash[i] = NULL;
	if (!(file = fopen("opcode.txt", "r"))) // opcode.txt 파일 스트림 열기
	{
		puts("opcode open error!");
		return 1;
	}
	// opcode.txt를 열어 해시함수를 이용하여 해시테이블에 링크드리스트 형식으로 저장
	while(fscanf(file, "%s", userinput) != EOF)
	{
		optemp = (Opcode*)malloc(sizeof(Opcode));
		strcpy(optemp->num, userinput);
		fscanf(file, "%s", userinput);
		strcpy(optemp->name, userinput);
		fscanf(file, "%s", userinput);
		tempnode = MakeNode((void*)optemp, (int)sizeof(optemp));
		tempnode->nextnode = ophash[HashFunction(optemp->name)];
		ophash[HashFunction(optemp->name)] = tempnode;
	}
	fclose(file); // 해시테이블을 완성하고 파일스트림을 다시 닫는다.

	for (i = 0; i < 1048576; ++i) // 메모리 값을 모두 0으로 초기화
		memory[i] = 0;
	// 사용자의 입력에 따라 알맞은 실행을 quit 메뉴를 열기전까지 반복하는 반복문
	while (1)
	{
		fputs("sicsim> ", stdout);
		fgets(userinput, 100, stdin); // 사용자의 입력을 받는다.
		userinput[strlen(userinput)-1] = '\0'; // fgets를 통해 받으면 입력값의 마지막에 '\n'가 저장되기 때문에 이를 '\0'값으로 바꾸어준다.

		which = WhichMenu(userinput, &start, &end, &value); // 함수 호출을 통해 which 변수에 해당 명령값을 저장한다.

		if (which == HELP) // help 명령시 실행. 어떤 명령이 있는지 알려준다.
		{
			puts("h[elp]");
			puts("d[ir]");
			puts("q[uit]");
			puts("hi[story]");
			puts("du[mp] [start, end]");
			puts("e[dit] address, value");
			puts("f[ill] start, end, value");
			puts("reset");
			puts("opcode mnemonic");
			puts("opcodelist");
			
			InsertHistoryList(&hlist, userinput);
		}
		else if (which == QUIT) // quit 명령시 실행. 동적할당한 것을 모두 free해주고 반복문을 나간다.
		{
			if ((hlist.head))
				DeleteLinkedList(&(hlist.head));
			for (i = 0; i < 20; ++i)
				if (ophash[i])
				DeleteLinkedList(&ophash[i]);
			break;
		}
		else if (which == HISTORY) // HistoryList 구조체를 통해 수행한 명령어를 모두 출력
		{
			InsertHistoryList(&hlist, userinput);
			tempnode = hlist.head;
			for (j = 1; j <= hlist.count; ++j)
			{
				printf("%d : %s\n", j, (char*)(tempnode->val));
				tempnode = tempnode->nextnode;
			}
		}
		else if (which == DI) // dir 명령어를 실행. 실행파일에 있는 모든 파일을 출력하고 폴더의 끝에는 /를 실행파일의 끝에는 *를 붙여 출력한다.
		{
			if ((dp = opendir(".")) == NULL) // 실행파일이 있는 폴더를 연다.
			{
				perror("error!");
				break;
			}

			while ((dent = readdir(dp))) // 실행파일의 있는 폴더의 내용을 하나씩 읽는다.
			{
				printf("%s", dent->d_name);
				stat(dent->d_name, &sbuf); // 파일의 정보를 저장한다.

				if (S_ISDIR(sbuf.st_mode)) // 폴더일시 끝에 /를 붙인다.
						printf("/");
				else if (sbuf.st_mode & S_IEXEC) // 실행파일이시 끝에 '*'을 붙인다.
						printf("*");
				puts("");
			}

			closedir(dp);
			InsertHistoryList(&hlist, userinput);
		}
		else if (which == DUMP) // dump 명령어를 실행. start 혹은 end 변수의 값이 -1인 것은 사용자가 시작주소값과 끝주소값을 입력하지 않은 것을 의미한다.
		{
			if (start == -1) // 시작 주소값이 입력되지 않았으므로 마지막으로 출력한 값의 다음값으로 설정한다. 만약 해당 값이 메모리 범위를 넘으면 0으로 초기화한다.
			{
				start = dumpadd+1;
				if (start >= 1048576)
					start = 0;
			}
			if (end == -1) // 끝 주소값이 입력되지 않았으므로 시작 주소값에 159를 더해줌으로써 160개의 출력을 할 수 있게 해준다. end가 만약 메모리 범위를 넘으면 메모리의 마지막 값으로 초기화한다.
			{
				end = start + 159;
				if (end >= 1048576)
					end = 1048575;
			}

			k = start; // k는 세미콜론 뒤 해당 케릭터를 출력할 인덱스이다.

			printf("%04X0 ", start/16);
			for (j = start - (start%16); j < start; ++j) // 만약 시작주소값이 해당 라인의 첫번째 값이 아니라면 공백을 출력한다.
				printf("   ");
			while (start <= end) // start는 1씩 더해지며 메모리의 start 인덱스를 참조해 추력한다. k와는 별개로 움직이므로 주의한다.
			{
				printf("%02hhX ", memory[start]);
				if (!((start+1) % 16)) // 만약 start가 라인의 마지막 값이면 세미콜론을 붙이고 해당 라인의 케릭터 값을 출력한다.
				{
					fputs("; ", stdout);
					for (j = k - (k%16); j < k; ++j) // 만약 사용자가 입력한 시작값이 해당 라인의 첫번째 값이 아니라면 시작값의 전 값은'.'으로 출력한다.
						putchar('.');
					do // 해당 인덱스의 값이 0x20과 0x7E 값 사이라면 값을 출력하고 아니면 '.'을 출력한다.
					{
						if (memory[k] >= 0x20 && memory[k] <= 0x7E)
							putchar(memory[k]);
						else
							putchar('.');
						++k;
					} while (k % 16); // 라인을 모두 출력할때까지 반복한다.

					puts("");
					if ((start+1) <= end)
						printf("%04X0 ", start/16 + 1);
				}
				++start;
			}
			// 아래의 코드의 경우 사용자가 입력한 끝값이 라인의 마지막 값이 아니라면 마지막라인을 마저 출력해주는 코드이다.
			for (j = end; j < end + 15 - end%16; ++j) // 만약 사용자가 입력한 끝값이 해당 라인의 마지막 값이 아니라면 남은 값들을 공백으로 출력한다.
			{
				printf("   ");
				if (j+1 == (end + 15 - end%16))
					fputs("; ", stdout);
			}
			while (k <= end) // 마지막 라인의 출력이 끝나면 사용자가 입력한 끝값까지 해당 케릭터 값을 출력한다.
			{
				if (memory[k] >= 0x20 && memory[k] <= 0x7E)
					putchar(memory[k]);
				else
					putchar('.');
				++k;
			}
			while (k < end + 16 - end%16) // 사용자가 입력한 끝값의 다음값부터는 '.'으로 케릭터를 출력한다.
			{
				putchar('.');
				if (k+1 == (end + 16 - end%16))
					puts("");
				++k;
			}

			dumpadd = end;
			InsertHistoryList(&hlist, userinput);
		}
		else if (which == EDIT) //edit 명령어를 실행. 사용자가 입력한 주소에 입력한 값을 저장한다.
		{
			memory[start] = value;
			InsertHistoryList(&hlist, userinput);
			printf("edit commend is successfully done!\n");
		}
		else if (which == FILL) // 사용자가 입력한 주소값들 사이에 입력한 값을 저장한다.
		{
			for (i = start; i <= end; ++i)
				memory[i] = value;
			InsertHistoryList(&hlist, userinput);
			printf("fill commend is successfully done!\n");
		}
		else if (which == RESET) // 모든 메모리를 0으로 초기화한다.
		{
			for (i = 0; i < 0xFFFFF; ++i)
				memory[i] = 0;
			InsertHistoryList(&hlist, userinput);
			printf("reset commend is successfully done!\n");
		}
		else if (which == OPMNEMONIC) // 해당 mnemonic에 해당하는 opcode를 출력한다. WhichMenu가 이 명령어를 반환시 start에는 userinput 문자열에서 사용자가 입력한 mnemonic의 시작 주소값이 value에는 입력한 mnemonic의 길이가 저장된다.
		{
			if (value > 100) // temparr의 문자열의 길이가 100이므로 사용자가 입력한 mnemonic이 100자가 넘을 시 99자로 줄여준다.
				value = 99;
			strncpy(temparr, &userinput[start], value);
			temparr[value] = '\0';
			printf("temparr : %s\n", temparr);
			tempnode = ophash[HashFunction(temparr)]; // 사용자가 입력한 값을 해시함수에 넣어 해당하는 해시테이블에서 값을 찾는다.
			while (tempnode)
			{
				if (strcmp(temparr, ((Opcode*)(tempnode->val))->name) == 0)
				{
					printf("opcode is %s\n", ((Opcode*)(tempnode->val))->num);
					break;
				}
				tempnode = tempnode->nextnode;
			}
			InsertHistoryList(&hlist, userinput);
			if (!tempnode) // 만약 해당 해시테이블에서 값이 없을 시 출력
				printf("there is not mnemonic you input!\n");
		}
		else if (which == OPLIST) // 해시테이블에 저장된 opcodelist를 출력한다.
		{
			for (i = 0; i < 20; ++i)
			{
				printf("%2d : ", i);
				for (tempnode = ophash[i]; tempnode; tempnode = tempnode->nextnode)
				{
					printf("[%s, %s]", ((Opcode*)(tempnode->val))->name, ((Opcode*)(tempnode->val))->num);
					if (tempnode->nextnode)
						printf(" -> ");
				}
				puts("");
			}
			InsertHistoryList(&hlist, userinput);
		}
		else
			printf("commend error! check you input.\n");
	}
	return 0;
}


Node* MakeNode(void* input, int size) // Node를 만들어 주는 함수. input값은 저장할 값의 주소값, size값은 input값의 바이트 크기. Node의 성분인 보이드형 포인트 변수인 val에 동적할당을 하고 memcpy 함수를 동해 메모리를 복사한다.
{
	Node* tempnode = (Node*)malloc(sizeof(Node));

	tempnode->val = malloc(size);
	tempnode->nextnode = NULL;

	memcpy(tempnode->val, input, size);

	return tempnode;
}
int WhichMenu(char* input, int *start, int *end, int *value) // 어떤 명령을 호출했는지 반환해주며 올바르지 않는 명령의 경우 -1를 반환해 무시하도록 한다. start, end, value를 받아 명령어에 따라 올바른 값을 저장.
{
	char testarr[100]; // input 매개변수의 값을 복사해 받는데 사용한다.
	char *token; // strtok함수를 사용할 때 반환 값을 저장하는 변수.
	int which = -1; // 어떤 명렁어를 호출 했는지 저장하는 변수
	int i, j, k; // 임시 정수 변수.
	char* temp, *temp1; // dump, edit, fill의 경우 ','의 위치를 저장하여 올바른 위치에 있는지 확인.

	if (input[0] == '\0') // 입력값의 없을시 -1을 반환
		return -1;
	// start, end, value 값을 모두 -1로 초기화
	*start = -1;
	*end = -1;
	*value = -1;

	strcpy(testarr, input);

	token = strtok(testarr, " \t"); // 문자열을 탭이나 뛰어쓰기 기준으로 자른다.

	if (strcmp(token, "h") == 0|| strcmp(token, "help") == 0) // 사용자가 help 명령을 올바르게 호출했으면 which에 HELP값을 저장한다.
	{
		if (!(token = strtok(NULL, " \t")))
			which = HELP;
	}
	else if (strcmp(token, "d") == 0|| strcmp(token, "dir") == 0) // 사용자가 dir 명령을 올바르게 호출했으면 which에 DI값을 저장한다.
	{
		if (!(token = strtok(NULL, " \t")))
			which = DI;
	}
	else if (strcmp(token, "q") == 0|| strcmp(token, "quit") == 0) // 사용자가 quit 명령을 올바르게 호출했으면 which에 QUIT값을 저장한다.
	{
		if (!(token = strtok(NULL, " \t")))
			which = QUIT;
	}
	else if (strcmp(token, "hi")  == 0|| strcmp(token, "history") == 0) // 사용자가 history 명령을 올바르게 호출했으면 which에 HISTORY값을 저장한다.
	{
		if (!(token = strtok(NULL, " \t")))
			which = HISTORY;
	}	
	else if (strcmp(token, "du") == 0|| strcmp(token, "dump") == 0) // 사용자가 dump 명령어를 올바르게 호출하면 which에 DUMP값을 저장하고 시작값을 입력했다면 start에 끝값을 입력했다면 end에 저장한다.
	{
		if ((token = strtok(NULL, " \t"))) // dump뒤에 더 입력한 문자열이 있는지 확인
		{
			temp = NULL;
			// strtok 호출하면 token화 하면서 testarr의 중간중간에 '\0'이 넣어지기 때문에 입력문자열을 다시 testarr에 저장하고 strtok를 다시 호출함으로써 token에 du나 dump의 첫번째 주소값이 저장되게 한다.
			// 또한 strtok가 토큰화하기 위해 저장한 '\0'값 뒤에 다음 값이 있음을 알고 있으므로 해당 값 뒤에 ','값이 있는지 확인하고 있을 시 temp에 첫번째 ','의 위치값을 저장한다.
			// 해당 ','주소값에 ' '를 저장해 strtok를 통해 ','값 앞과 뒤가 token화 되게 한다.
			strcpy(testarr, input);
			token = strtok(testarr, " \t");
			for (i = 1; *(token + strlen(token) +i) != '\0'; ++i)
				if (*(token + strlen(token)+i) == ',')
				{
					*(token+strlen(token)+i) = ' ';
					temp = token + strlen(token) +i;
					break;
				}
			
			if (!(token = strtok(NULL, " \t"))) // strtok에는 더이상 token화 할게 없으면 NULL문자를 반환한다. 만약 dump 명령어 뒤에 ','한자만 있을시 앞서 ' '로 바뀜으로써 토큰화 할게 없어 NULL를 반환하는데 이때 -1를 반환한다.
				return -1;
			if (temp && (temp < token)) // temp의 주소값이 token의 주소값 즉, 시작값보다 앞에 있을시 잘못된 입력이므로 -1을 반환한다. ex) du ,1
				return -1;
			// 시작값의 문자열 값만 샌다. 이때 값은 숫자나 대소문자 a부터 f까지 값만 인정한다.
			for (i = 0; (token[i] >= '0' && token[i] <= '9') || (token[i] >= 'a' && token[i] <= 'f') || (token[i] >= 'A' && token[i] <= 'Z'); ++i);

			if (token[i] == '\0') // 시작값에 16진수에 해당하는 문자만 있으면 if문 안에 들어간다.
			{
				if (strlen(token) > 6) // 너무 긴 시작값의 경우 메모리값을 초과하므로 -1을 반환
					return -1;
				//시작주소값을 start에 저장
				*start = 0;
				k = 1;
				for (i-=1; i >=0; --i)
				{
					if (token[i] >= '0' && token[i] <= '9')
						*start = *start + k * (token[i] - '0');
					else if (token[i] >= 'a' && token[i] <= 'z')
						*start = *start + k * (token[i] + 10 - 'a');
					else
						*start = *start + k * (token[i] + 10 - 'A');
					k *= 16;
				}
				
				if (*start >= 1048576) // start의 값이 메모리 범위를 벗어나면 -1 반환
					return -1;
				
				if ((token = strtok(NULL, " \t"))) // 시작값 뒤에도 입력한 문자열이 있을시 들어간다.
				{
					if (!temp || token < temp) // temp의 값이 NULL일 경우 즉, ','의 값이 없었거나 temp의 주소값이 끝값의 시작주소보다 뒤에 있을 시 잘못된 입력이므로 -1을 반환
						return -1;
					for (i = 0; (token[i] >= '0' && token[i] <= '9') || (token[i] >= 'a' && token[i] <= 'f') || (token[i] >= 'A' && token[i] <= 'Z'); ++i);

					if (token[i] == '\0') // 끝값을 저장한다.
					{
						if (strlen(token) > 7)
							return -1;
						*end = 0;
						k = 1;
						for (i -= 1; i >=0; --i)
						{
							if (token[i] >= '0' && token[i] <= '9')
								*end = *end + k * (token[i] - '0');
							else if (token[i] >= 'a' && token[i] <= 'z')
								*end = *end + k * (token[i] + 10 - 'a');
							else
								*end = *end + k * (token[i] + 10 - 'A');
							k *= 16;
						}

						if (*end < *start || *end >= 1048576)
							return -1;
						if ((token = strtok(NULL, " \t"))) // 끝값 뒤에도 입력한 문자열이 있으면 잘못된 문자열이므로 -1을 반환
								return -1;
						which = DUMP;
					}
				}
				else // 끝값을 입력하지 않았을시
				{
					if (temp) // 끝값을 입력하지 않았으나 ','가 있으면 잘못된 입력이므로 -1을 반환
						return -1;
					which = DUMP;
				}
			}

		}
		else // dump만 입력했을 시
			which = DUMP;
		
	}
	else if (strcmp(token, "e") == 0|| strcmp(token, "edit") == 0) // 사용자가 edit 명령을 올바르게 호출하면 which에 EDIT을 저장하고 start 변수에 주소값을 value 변수에 저장할 값을 저장한다.
	{
		// 예외처리 및 저장방식은 위의 dump와 동일하다.
		if ((token = strtok(NULL, " \t")))
		{
			strcpy(testarr, input);
			token = strtok(testarr, " \t");
			temp = NULL;
			for (i = 1; *(token + strlen(token) +i) != '\0'; ++i)
				if (*(token + strlen(token)+i) == ',')
				{
					*(token+strlen(token)+i) = ' ';
					temp = token + strlen(token)+i;
					break;
				}
			
			if (!(token = strtok(NULL, " \t")))
				return -1;

			if (temp == NULL || temp < token)
				return -1;

			for (i = 0; (token[i] >= '0' && token[i] <= '9') || (token[i] >= 'A' && token[i] <= 'F') || (token[i] >= 'a' && token[i] <= 'f'); ++i);


			if (token[i] == '\0')
			{
				if (strlen(token) > 6)
					return -1;
				*start = 0;
				k = 1;
				for (i-=1; i >=0; --i)
				{
					if (token[i] >= '0' && token[i] <= '9')
						*start += k * (token[i] - '0');
					else if(token[i] >= 'a' && token[i] <= 'z')
						*start += k * (token[i] - 'a' + 10);
					else
						*start += k * (token[i] - 'A' + 10);
					k *= 16;
				}
				
				if (*start >= 0xFFFFF)
					return -1;

				if ((token = strtok(NULL, " \t")))
				{
					if (temp > token)
						return -1;
					for (i = 0; (token[i] >= '0' && token[i] <= '9') || (token[i] >= 'A' && token[i] <= 'F') || (token[i] >= 'a' && token[i] <= 'f'); ++i);

					if (token[i] == '\0')
					{
						if (strlen(token) > 2)
							return -1;
						*value = 0;
						k = 1;
						for (i -= 1; i >= 0; --i)
						{
							if (token[i] >= '0' && token[i] <= '9')
								*value += k * (token[i] - '0');
							else if(token[i] >= 'a' && token[i] <= 'z')
								*value += k * (token[i] - 'a' + 10);
							else
								*value += k * (token[i] - 'A' + 10);
							k *= 16;
						}
						which = EDIT;
					}
				}
			}
		}
	}
	else if (strcmp(token, "f") == 0 || strcmp(token, "fill") == 0) // 사용자가 fill 명령어를 올바르게 호출시 which에 FILL을 저장하고 start에는 시작값을 end에는 끝값을 value에는 저장할 값을 저장한다.
	{
		// 예외처리 및 저장방식은 위의 dump와 동일하다.
		if ((token = strtok(NULL, " \t")))
		{
			strcpy(testarr, input);
			token = strtok(testarr, " \t");
			temp = NULL; // temp의 경우 첫번째 ','의 주소값을 저장한다.

			for (i = 1; *(token + strlen(token) +i) != '\0'; ++i)
				if (*(token + strlen(token)+i) == ',')
				{
					*(token+strlen(token)+i) = ' ';
					temp = token+strlen(token)+i;
					break;
				}

			if (!(token = strtok(NULL, " \t")))
				return -1;
			if (temp == NULL || temp < token)
				return -1;

			for (i = 0; (token[i] >= '0' && token[i] <= '9') || (token[i] >= 'A' && token[i] <= 'F') || (token[i] >= 'a' && token[i] <= 'f'); ++i);

			if (token[i] == '\0')
			{
				if (strlen(token) > 7)
					return -1;

				*start = 0;
				k = 1;
				for (i-=1; i >=0; --i)
				{
					if (token[i] >= '0' && token[i] <= '9')
						*start += k * (token[i] - '0');
					else if(token[i] >= 'a' && token[i] <= 'z')
						*start += k * (token[i] - 'a' + 10);
					else
						*start += k * (token[i] - 'A' + 10);
					k *= 16;
				}
				
				if (*start >= 1048576)
					return -1;

				temp1 = NULL; // temp1의 경우 두번째 ','의 주소값을 저장한다.
				for (i = 1; *(token + strlen(token) + i) != '\0'; ++i)
					if (*(token + strlen(token)+i) == ',')
					{
						*(token+strlen(token)+i) = ' ';
						temp1 = token + strlen(token)+i;
						break;
					}
				
				if ((token = strtok(NULL, " \t")))
				{
					if (temp1 == NULL || temp1 < token || temp > token)
						return -1;
					for (i = 0; (token[i] >= '0' && token[i] <= '9') || (token[i] >= 'A' && token[i] <= 'F') || (token[i] >= 'a' && token[i] <= 'f'); ++i);

					if (token[i] == '\0')
					{
						if (strlen(token) > 7)
							return -1;
						*end = 0;
						k = 1;
						for (i -= 1; i >=0; --i)
						{
							if (token[i] >= '0' && token[i] <= '9')
								*end += k * (token[i] - '0');
							else if(token[i] >= 'a' && token[i] <= 'z')
								*end += k * (token[i] - 'a' + 10);
							else
								*end += k * (token[i] - 'A' + 10);
							k *= 16;
						}
						
						if (*end >= 1048576 || *start > *end)
							return -1;

						if ((token = strtok(NULL, " \t")))
						{
							if (temp1 > token)
								return -1;
							for (i = 0; (token[i] >= '0' && token[i] <= '9') || (token[i] >= 'A' && token[i] <= 'F') || (token[i] >= 'a' && token[i] <= 'f'); ++i);

							if (token[i] == '\0')
							{	
								if (strlen(token) > 2)
									return -1;
								*value = 0;
								k = 1;
								for (i -= 1; i >= 0; --i)
								{
									if (token[i] >= '0' && token[i] <= '9')
										*value += k * (token[i] - '0');
									else if(token[i] >= 'a' && token[i] <= 'z')
										*value += k * (token[i] - 'a' + 10);
									else
										*value += k * (token[i] - 'A' + 10);
									k *= 16;
								}

								if ((token = strtok(NULL, " \t")))
									return -1;
								which = FILL;
							}
						}
					}
				}
			}
		}
	}
	else if (strcmp(token, "reset") == 0) // 사용자가 reset값을 올바르게 호출시 which에 RESET을 저장한다.
	{
		if (!(token = strtok(NULL, " \t")))
			which = RESET;
	}
	else if (strcmp(token, "opcodelist") == 0) // 사용자가 opcodelist을 올바르게 호출 시 which에 OPLIST를 저장한다.
	{
		if (!(token = strtok(NULL, " \t")))
			which = OPLIST;
	}
	else if (strcmp(token, "opcode") == 0) // 사용자가 opcode mnemonic을 올바르게 호출시 which에 OPMNEMONIC을 저장하고 start에 사용자가 입력한 문자열에서 mnemonic이 나오는 시작 주소값을 value에 입력한 mnemonic의 길이를 저장한다.
	{
		if ((token = strtok(NULL, " \t"))) // opcode 뒤에 사용자가 입력한 문자열이 있는지 확인
		{
			if (strlen(token) > 6) // 입력한 mnemonic이 6자보다 큰값인 경우 -1을 반환한다.
				return -1;
			// 문자열에서 mnemonic의 위치를 찾는다.
			for (i = 0; i < strlen(input); ++i)
			{
				j = 0;
				if (input[i] == token[j])
				{
					for (k = 0; k < strlen(token); ++k)
						if (input[i+k] != token[j+k])
							break;
					if (k == strlen(token))
					{
						*start = i;
						*value = strlen(token);
						break;
					}
				}
			}
			if (!(token = strtok(NULL, " \t")))
				which = OPMNEMONIC;
		}
	}

	return which;
}
int HashFunction(char* key) // key를 받아 해당하는 해시값을 반환한다.
{
	int hash = 0;
	int i = 0;
	int len = strlen(key);

	for(i = 0; i < len; ++i)
		hash = hash*31 + key[i];

	return hash % 20;
}
void DeleteLinkedList(Node** head) // 링크드리스트의 head의 주소값을 받아 해당 리스트의 동적할당을 해제한다.
{
	Node* tempnode = *head;
	Node* nextnode;

	while (tempnode)
	{
		nextnode = tempnode->nextnode;
		free(tempnode->val);
		free(tempnode);
		tempnode = nextnode;
	}

	*head = NULL;
}
void InsertHistoryList(HistoryList* hlist, char* data) // HistoryList와 사용자의 입력 문자열을 받아 새로이 저장한다.
{
	Node* tempnode = MakeNode((void*)data, (int)strlen(data)+1);

	if (hlist->count == 0)
	{
		hlist->head = tempnode;
		hlist->tail = tempnode;
	}
	else
	{
		hlist->tail->nextnode = tempnode;
		hlist->tail = tempnode;
	}
	hlist->count += 1;
}
