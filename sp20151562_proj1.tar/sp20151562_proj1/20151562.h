#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
//사용자가 어떤 메뉴를 선택할지 결정한 것을 enum 자료형을 통해 가독성을 올린다.
enum Menu{ 
	HELP, DI, QUIT, HISTORY, DUMP, EDIT, FILL, RESET, OPMNEMONIC, OPLIST
};
//Node에 관련된 구조체. val은 노드의 저장할 데이터의 주소값을 저장
typedef struct tagNode{
	void* val;
	struct tagNode *nextnode;
} Node;
// 사용자가 올바른 입력을 했을 시 입력한 명령을 링크스리스트로 저장해 관리하는 구조체
// 변수 count는 저장한 명령의 개수를 저장하고 head는 가장 앞 노드의 주소값을 저장, tail은 가장 끝 노드의 주소값을 저장
typedef struct tagHistoryList{
	int count;
	Node* head;
	Node* tail;
}HistoryList;
//opcode의 이름과 해당 OPcode의 16진수 값을 저장하는 구조체
typedef struct tagOpcode{
	char num[3];
	char name[10];
}Opcode;

Node* MakeNode(void* input, int size); // 노드를 만들고 input값을 val에 저장하고 만든 노드의 주소를 반환. size는 데이터의 바이트 크기.
int WhichMenu(char* input, int *start, int *end, int *value); // 사용자가 입력한 값을 통해 어떤 명령을 선택했는지 반환. start와 end, value는 사용자가 dump, edit, fill 명령을 선택했을 시 입력한 주소값과 저장할 값을 각각의 값에 저장
int HashFunction(char *key); //key를 넣으면 해쉬값을 반환.
void DeleteLinkedList(Node** head); //linkedlist의 동적할당을 free 한다.
void InsertHistoryList(HistoryList* hlist, char* data); //사용자가 입력한 문자열을 HistoryList 구조체에 넣는다.