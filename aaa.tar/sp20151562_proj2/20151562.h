#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
//사용자가 어떤 메뉴를 선택할지 결정한 것을 enum 자료형을 통해 가독성을 올린다.
enum Menu{ 
	HELP, DI, QUIT, HISTORY, DUMP, EDIT, FILL, RESET, OPMNEMONIC, OPLIST, ASSEMBLE, TYPE, SYMBOL
};
enum Directive{
	START = 100, END, BYTE, WORD, RESB, RESW, BASE
};
//Node에 관련된 구조체. val은 노드의 저장할 데이터의 주소값을 저장
typedef struct tagNode{
	void* val;
	struct tagNode *nextnode;
} Node;
// LinkedLIst를 관리하는 구조체
// 변수 count는 저장한 명령의 개수를 저장하고 head는 가장 앞 노드의 주소값을 저장, tail은 가장 끝 노드의 주소값을 저장
typedef struct tagLinkedList{
	int count;
	Node* head;
	Node* tail;
}LinkedList;
//opcode의 이름과 해당 OPcode의 16진수 값을 저장하는 구조체
typedef struct tagOpcode{
	char num[3];
	char name[10];
	char form[5]; 
}Opcode;
// asm파일에서 한줄에 있는 symbol, instruction, operand의 값을 정리해 저장
typedef struct tagAssembleline{
	int address;
	char symbol[10];
	char instruction[10];
	char operand[100];
	char operand2;
	int byte;
} Assembleline;
// symbol 
typedef struct tagSymbol{
	char name[10];
	int address;
}Symbol;

Node* MakeNode(void* input, int size); // 노드를 만들고 input값을 val에 저장하고 만든 노드의 주소를 반환. size는 데이터의 바이트 크기.
int WhichMenu(char* input, int *start, int *end, int *value); // 사용자가 입력한 값을 통해 어떤 명령을 선택했는지 반환. start와 end, value는 사용자가 dump, edit, fill 명령을 선택했을 시 입력한 주소값과 저장할 값을 각각의 값에 저장
int HashFunction(char *key); //key를 넣으면 해쉬값을 반환.
void DeleteLinkedList(Node** head); //linkedlist의 동적할당을 free 한다.
void InsertHistoryList(LinkedList* hlist, char* data); //사용자가 입력한 문자열을 HistoryList 구조체에 넣는다
int FindDirective(char *arr); // 해당 문자열이 direcive일 경우 각각의 경우에 맞는 enum값을 아닐 경우 -1을 return
Node* FindOphash(char *input, Node* ophash[]);// 해당 문자열의 이름을 가진 instruction이 있는지 opcode table에서 찾은후 있으면 해당 주소값을 없으면 NULL값을 return
// 해당 문자열이 10진수 혹은 16진수 혹은 character 형이 맞는지 확인하고 맞을 경우 해당 값을 저장하기 위해 몇 byte가 필요한지 return. 올바른 형식이 아닐 경우 -1을 return
// ex) 16진수 : X'1F' / 10진수 : 123 / character : C'HELLO'
int CheckConstant(char* input);
